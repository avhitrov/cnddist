-- Adjust this setting to control where the objects get created.
SET search_path = public;

DROP FUNCTION fti() CASCADE; 
