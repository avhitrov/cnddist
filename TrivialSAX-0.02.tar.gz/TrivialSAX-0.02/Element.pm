##############################################################################
# $HeadURL: svn://cvs1.rambler.ru/Bicycle/XML-TrivialSAX/XML/TrivialSAX/Element.pm $
# $Id: Element.pm 6 2006-07-11 08:04:53Z lonerr $
#
# TODO: some docs
##############################################################################
package XML::TrivialSAX::Element;

use strict;
use warnings 'all';
use vars qw($VERSION);


$VERSION = '0.01';

sub new {
	my ($package, $name, %opts) = @_;
	my $self = {
		name        => $name,
		attrs       => $opts{attrs}    || {},
		children    => $opts{children} || {},
		content     => $opts{content}  || '',
		allow_undef => $opts{allow_undef},
   	};

	bless $self, $package;
}

sub name {
	shift->{name};
}

sub attrs {
	shift->{attrs};
}

sub attr {
	my ($self, $attr) = @_;

	$self->{attrs}->{$attr} || ($self->{allow_undef} ? undef : '');
}

sub content {
	my $self = shift;

	$self->{content} = shift if @_;
	$self->{content} || ($self->{allow_undef} ? undef : '');
}

sub children {
	# Returns collection of children by name.
	# Collection may be an empty.
	my ($self, $name) = @_;

	$name ? $self->{children}->{$name} || [] : $self->{children};
}

sub child {
	# Returns first child by name or undef if none.
	my ($self, $name) = @_;

	scalar(@{$self->children($name)}) ? $self->children($name)->[0] : undef;
}

sub add_child {
	my ($self, $child) = @_;

	$self->{children}->{$child->name} ||= [];
	push @{$self->{children}->{$child->name}}, $child;
}

1;
