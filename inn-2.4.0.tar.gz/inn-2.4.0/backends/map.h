/*  $Id: map.h,v 1.1 2002/03/10 08:59:53 vinocur Exp $
**
*/

void  MAPfree(void);                    /* free the map */
void  MAPread(const char *name);        /* read the map file */
char *MAPname(char *p);                 /* lookup in the map */
