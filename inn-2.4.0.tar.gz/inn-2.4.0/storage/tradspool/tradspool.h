/*
** $Id: tradspool.h,v 1.7 2001/01/04 06:04:10 rra Exp $
** tradspool -- storage manager for traditional spool format.
*/

#ifndef __TRADSPOOL_H__
#define __TRADSPOOL_H__

#include "config.h"
#include "interface.h"

bool tradspool_init(SMATTRIBUTE *attr);
TOKEN tradspool_store(const ARTHANDLE article, const STORAGECLASS class);
ARTHANDLE *tradspool_retrieve(const TOKEN token, const RETRTYPE amount);
ARTHANDLE *tradspool_next(const ARTHANDLE *article, const RETRTYPE amount);
void tradspool_freearticle(ARTHANDLE *article);
bool tradspool_cancel(TOKEN token);
bool tradspool_ctl(PROBETYPE type, TOKEN *token, void *value);
bool tradspool_flushcacheddata(FLUSHTYPE type);
void tradspool_printfiles(FILE *file, TOKEN token, char **xref, int ngroups);
void tradspool_shutdown(void);

#endif
