/* 
 * Copyright (C) 1998,2000 Dmitry Khrustalev
 *            original gzip patch for Apache 1.3.1.
 *
 * Copyright (C) 2001 Igor Sysoev
 *            porting patch to module,
 *            adding configuration directives, deflate encoding,
 *            FreeBSD idle state checking, documentation.
 *
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 /

/*
MODULE-DEFINITION-START
Name: deflate_module
ConfigStart
  CFLAGS="$CFLAGS -DMOD_DEFLATE"

  LIBS="$LIBS -lz"
  echo "      using -lz for compression support"

  if [ -r ../mod_deflate.conf ]; then
    . ../mod_deflate.conf
  fi
ConfigEnd
MODULE-DEFINITION-END
*/

#include "httpd.h"
#include "http_core.h"
#define CORE_PRIVATE
#include "http_config.h"
#undef CORE_PRIVATE
#include "http_conf_globals.h"
#include "http_protocol.h"
#include "http_log.h"
#include "scoreboard.h"
#include "zlib.h"

#define MOD_DEFLATE_VER "mod_deflate/1.0.12"

#define UNSET           -1

#define init(field, default)    if (field == UNSET) field = default
    
#define merge(merged, parent, child, field)                              \
              merged->field = child->field == UNSET ?                    \
                              parent->field : child->field


static const int flush_map[] = { Z_NO_FLUSH, Z_SYNC_FLUSH, Z_FINISH };

module deflate_module;
static int deflate_content_type(request_rec *r, table *t);

typedef struct {
    z_stream     *zstream;
    request_rec  *r;
    int           crc32;
    int           encoding;
    int           last_flush;
} deflate_rec;

typedef struct {
    char         *agent; 
} deflate_agent;

typedef struct {
#ifdef MOD_DEFLATE_IDLE
    int           idle;
    int           period;
#endif
} deflate_server_conf;

typedef struct {
    int           enable;
    int           min_version;
    int           proxied;
    int           first;
    int           second;
    int           comp_level;
    int           length;
    table        *types;
    array_header *disable_range;
} deflate_dir_conf;

static const char gzheader[10] =
                 { 0x1f, 0x8b, Z_DEFLATED, 0, 0, 0, 0, 0, 0, 3 };

struct gztrailer {
    int           crc32;
    int           zlen;
};



#ifdef MOD_DEFLATE_IDLE
#define IDLE_CHECK_PERIOD 1

static int check_period;
static int slot_num = -1;

#ifdef __FreeBSD__

#include <kvm.h>

static struct nlist namelist[] = {
    { "_cp_time" },
    { "" }
};

static kvm_t *kd = NULL;
static int idle = 0;
static long p_time_cnts[5];
static long t_sys, t_intr, t_user, t_nice, t_idle;

static void cleanup(void *data);

static void start_idle_state(server_rec *s, pool *p)
{
    char error[_POSIX2_LINE_MAX];

    if (!(kd = kvm_openfiles(NULL, NULL, NULL, O_RDONLY, error))) {
        ap_log_error(APLOG_MARK, APLOG_NOERRNO|APLOG_ERR, s,
                     "mod_deflate: kvm_openfiles() failed: %s", error);
        exit(1);
    }

    if (kvm_nlist(kd, namelist)) {
        ap_log_error(APLOG_MARK, APLOG_NOERRNO|APLOG_ERR, s,
                     "mod_deflate: kvm_nlist() failed: %s", kvm_geterr(kd));
        exit(1);
    }

    set_deflate_max(s);

    ap_register_cleanup(p, NULL, cleanup, ap_null_cleanup);
}

static void cleanup(void *data)
{
    kvm_close(kd);
}

void set_deflate_max(server_rec *s)
{
    int i, current;
    long d_sys, d_intr, d_user, d_nice, d_idle, d_all;
    global_score *score;

    deflate_server_conf *conf = (deflate_server_conf *)
                       ap_get_module_config(s->module_config, &deflate_module);

    if (!kd || ++check_period < conf->period)
        return;

    check_period = 0;

    if (kvm_read(kd, namelist[0].n_value, p_time_cnts, sizeof(p_time_cnts))
            != sizeof( p_time_cnts)) {
        ap_log_error(APLOG_MARK, APLOG_NOERRNO|APLOG_ERR, s,
                     "mod_deflate: kvm_read() failed: %s", kvm_geterr(kd));
        return;
    }

    d_sys  = t_sys - p_time_cnts[0];  t_sys = p_time_cnts[0];
    d_intr = t_intr - p_time_cnts[1]; t_intr = p_time_cnts[1];
    d_user = t_user - p_time_cnts[2]; t_user = p_time_cnts[2];
    d_nice = t_nice - p_time_cnts[3]; t_nice = p_time_cnts[3];
    d_idle = t_idle - p_time_cnts[4]; t_idle = p_time_cnts[4];

    d_all = d_sys + d_intr + d_user + d_nice + d_idle;

    if (d_all == 0)
        return;

    idle = (d_idle * 100) / d_all;

    if (!ap_scoreboard_image)
        return;

    current = 0;
    ap_sync_scoreboard_image();
    for (i = 0; i < HARD_SERVER_LIMIT; i++)
        if (ap_scoreboard_image->servers[i].deflate)
            current++;

    score = &ap_scoreboard_image->global;

#if 0
    ap_log_error(APLOG_MARK, APLOG_NOERRNO|APLOG_INFO, s,
                 "mod_deflate: %d%% %d:%d:%d", idle,
                 score->deflate_current, score->deflate_peak,
                 score->deflate_max);
#endif

#if 0
    if (score->deflate_peak < score->deflate_current) {
        score->deflate_current = 0;
        score->deflate_peak = 0;
        score->deflate_max = 0;
    }
#endif

    if (idle > conf->idle) {
        if (score->deflate_max <= score->deflate_peak)
            score->deflate_max = score->deflate_peak + 1;
    } else {
        score->deflate_max = score->deflate_peak - 1;
    }

    score->deflate_peak = 0;
    score->deflate_current = current;
}
#endif /* FreeBSD idle */

#endif /* MOD_DEFLATE_IDLE */



static void deflate_init(server_rec *s, pool *p)
{
    deflate_server_conf *conf = (deflate_server_conf *)
                       ap_get_module_config(s->module_config, &deflate_module);

    ap_add_version_component(MOD_DEFLATE_VER);

#ifdef MOD_DEFLATE_IDLE
    if (conf->idle > 0) {
        init(conf->period, 1);
        check_period = conf->period;
        start_idle_state(s, p);
    }
#endif
}

static int deflate_post_read(request_rec *r)
{
#ifdef MOD_DEFLATE_IDLE
    deflate_server_conf *conf;
#endif
    deflate_rec *d;

    if (r->main)
        return DECLINED;

#ifdef MOD_DEFLATE_IDLE
    conf = (deflate_server_conf *)
               ap_get_module_config(r->server->module_config, &deflate_module);

    if (conf->idle > 0 && slot_num >= 0) {
        ap_sync_scoreboard_image();
        ap_scoreboard_image->servers[slot_num].deflate = 0; 
    }
#endif

    if (r->connection->client->deflate == NULL)
        r->connection->client->deflate =
                  ap_pcalloc(r->connection->client->pool, sizeof(deflate_rec));

    d = r->connection->client->deflate;

    d->r = r;
    d->encoding = UNSET;

    return DECLINED;
}

int deflate_disable_byterange(request_rec *r)
{
    int            i;
    const char    *user_agent;
    deflate_agent *disabled;

    deflate_rec *d = (deflate_rec *) r->connection->client->deflate;

    deflate_dir_conf *conf = (deflate_dir_conf *)
                      ap_get_module_config(r->per_dir_config, &deflate_module);

    if (!(user_agent = ap_table_get(r->headers_in, "User-Agent"))
            || r->main)
        return 0;

    disabled = (deflate_agent *) conf->disable_range->elts;
    for (i = 0; i < conf->disable_range->nelts; i++)
        if (strstr(user_agent, disabled->agent)) {
            d->encoding = deflate_content_encoding(r);
            return d->encoding;
        }

    return 0;
}

/*
   We does not allow gzip/deflate encoding if
        request is subrequest
        request version is lower then given version (default is HTTP/1.1)
        some module already set content encoding
        response status is not HTTP_OK
        response has no body
        system idle is less then given (when compiled with MOD_DEFLATE_IDLE)
        content type is not allowed
        client does not accept gzip/deflate encoding
        proxied requests are not enabled and there is Via header
        response's Content-Length is less the given

   Also "no_gzip" and "no_deflate" enviroment variables allow to disable
   encoding method explicity
*/

int deflate_content_encoding(request_rec *r)
{
    const char *accept, *len, *user_agent;

    int deflate = 0;
    int gzip = 0;
    int method = 0;

    deflate_rec *d = (deflate_rec *) r->connection->client->deflate;

#ifdef MOD_DEFLATE_IDLE
    deflate_server_conf *sconf = (deflate_server_conf *)
               ap_get_module_config(r->server->module_config, &deflate_module);
#endif

    deflate_dir_conf *conf = (deflate_dir_conf *)
                     ap_get_module_config(r->per_dir_config, &deflate_module);

    /* d can be NULL if ap_read_request() sets HTTP_BAD_REQUEST */
    if (d == NULL)
        return 0;

    init(conf->min_version, HTTP_VERSION(1,1));

    /* check changes that can happen between
       ap_set_byterange() and ap_send_http_header() */
    if (d->encoding != UNSET
        && r->status == HTTP_OK
        && !r->content_encoding
        && !ap_table_get(r->headers_out, "Content-Encoding")
       )
    {
        return d->encoding;
    }

    if (conf->enable != 1
        || r->main
        || r->proto_num < conf->min_version
        || r->status != HTTP_OK
        || r->header_only
        || r->content_encoding
        || ap_table_get(r->headers_out, "Content-Encoding")
        || !deflate_content_type(r, conf->types)
        || !(accept = ap_table_get(r->headers_in, "Accept-Encoding"))
        || (conf->proxied != 1 && ap_table_get(r->headers_in, "Via"))
        || (conf->length > 0
            && (len = ap_table_get(r->headers_out, "Content-Length"))
            && conf->length > atoi(len))
       )
        return 0;

#ifdef MOD_DEFLATE_IDLE
    if (sconf->idle > 0) {
        ap_sync_scoreboard_image();

        /* it seems that best place to init slot_num is child init phase
           but sometimes scoreboard is not ready */
        if (slot_num < 0) {
            int i, pid;
            pid = getpid();
            for (i = 0; i < ap_daemons_limit; i++)
                if (ap_scoreboard_image->parent[i].pid == pid) {
                    slot_num = i;
                    break;
                }
        }

        /* and even here sometimes scoreboard is not ready */
        if (slot_num >= 0) {
            if (ap_scoreboard_image->global.deflate_current
                   >= ap_scoreboard_image->global.deflate_max)
            {
                ap_scoreboard_image->servers[slot_num].deflate = 0; 
                ap_table_set(r->notes, "defl_m", "b");

#if 0
                ap_log_rerror(APLOG_MARK, APLOG_NOERRNO|APLOG_INFO, r,
                              "mod_deflate: blocked: %d:%d:%d",
                              ap_scoreboard_image->global.deflate_current,
                              ap_scoreboard_image->global.deflate_peak,
                              ap_scoreboard_image->global.deflate_max);
#endif

                return 0;
            }

            ap_scoreboard_image->servers[slot_num].deflate = 1; 

            if (ap_scoreboard_image->global.deflate_peak
                   < ++ap_scoreboard_image->global.deflate_current)
                ap_scoreboard_image->global.deflate_peak =
                             ap_scoreboard_image->global.deflate_current;

#if 0
            ap_log_rerror(APLOG_MARK, APLOG_NOERRNO|APLOG_INFO, r,
                          "mod_deflate: %d:%d:%d",
                          ap_scoreboard_image->global.deflate_current,
                          ap_scoreboard_image->global.deflate_peak,
                          ap_scoreboard_image->global.deflate_max);
#endif
        }
    }
#endif

    init(conf->first, M_GZIP);    
    init(conf->second, 0);    

    /* check broken browsers */
    user_agent = ap_table_get(r->headers_in, "User-Agent");

    /* it seems that MSIE 4.x can't handle compressed stream
       if URL (without "http://" prefix) is longer then 253 bytes */
    if (user_agent
        && strstr(user_agent, "MSIE 4")
        && (r->hostname ? strlen(r->hostname) : 0)
           + (r->unparsed_uri ? strlen(r->unparsed_uri) : 0) > 200)
        return 0;

    /* Mozilla 0.9.1 can't parse Content-Encoding with trailing spaces */
    if (user_agent && strstr(user_agent, "rv:0.9.1) Gecko/"))
        return 0;

    if ((conf->first == M_DEFLATE || conf->second == M_DEFLATE)
         && !ap_table_get(r->subprocess_env, "no_deflate")
         && ap_find_token(r->pool, accept, "deflate")
         && (!user_agent
                               /* Konqueror can't handle deflate */
             || (user_agent && !strstr(user_agent, "Konqueror"))))
        deflate = 1;

    if ((conf->first == M_GZIP || conf->second == M_GZIP)
         && !ap_table_get(r->subprocess_env, "no_gzip")
         && ap_find_token(r->pool, accept, "gzip"))
        gzip = 1;

    if (conf->first == M_DEFLATE && deflate)
        method = M_DEFLATE;
    else if (conf->first == M_GZIP && gzip)
        method = M_GZIP;

    if (!method)
        if (conf->second == M_DEFLATE && deflate)
            method = M_DEFLATE;
        else if (conf->second == M_GZIP && gzip)
            method = M_GZIP;

    return method;
}

void deflate_start(BUFF *fb, int flag)
{
    int status;

    deflate_rec *d = (deflate_rec *) fb->deflate;

    deflate_dir_conf *conf = (deflate_dir_conf *)
                  ap_get_module_config(d->r->per_dir_config, &deflate_module);

    if (d->zstream)
        memset(d->zstream, 0, sizeof(z_stream));
    else
        d->zstream = ap_pcalloc(fb->pool, sizeof(z_stream));

    /* use malloc */
    /* set by pcalloc() or memset()
    d->zstream->zalloc = Z_NULL;
    d->zstream->zfree  = Z_NULL;
    d->zstream->opaque = Z_NULL;
    */

    if (conf->comp_level == UNSET)
        conf->comp_level = 1;

    status = deflateInit2(d->zstream, conf->comp_level, Z_DEFLATED,
                          -MAX_WBITS, MAX_MEM_LEVEL, Z_DEFAULT_STRATEGY);

    if (status != Z_OK) {
        ap_log_rerror(APLOG_MARK, APLOG_NOERRNO|APLOG_ERR, d->r,
                      "mod_deflate: deflateInit2 failed: %d", status);
        fb->flags &= ~B_COMPRESSED;
        return;
    }

    /* write a minimal gzip header */
    if (flag & B_GZIP) {
        d->crc32 = crc32(0L, Z_NULL, 0);
        ap_internal_bwrite(fb, gzheader, sizeof(gzheader));
    }

    d->last_flush = UNSET;
}

int ap_deflate_bwrite(BUFF *fb, const void *buf, int nbyte, int flush)
{
    int redo = 0;
    char zbuf[HUGE_STRING_LEN];
    deflate_rec *d = (deflate_rec *) fb->deflate;

    flush = flush_map[flush];

    if (flush == Z_SYNC_FLUSH && d->last_flush == Z_SYNC_FLUSH)
        return 0;

    d->last_flush = flush;

    d->zstream->next_in = (void *)buf;
    d->zstream->avail_in = nbyte;

    if (nbyte != 0 && fb->flags & B_GZIP)
        d->crc32 = crc32(d->crc32, buf, nbyte);

    if (flush != Z_NO_FLUSH)
        redo = 1;

    while (d->zstream->avail_in > 0 || redo) {
        int status, nout;
        char *t;

        redo = 0;
        d->zstream->next_out = zbuf;
        d->zstream->avail_out = HUGE_STRING_LEN;
        status = deflate(d->zstream, flush);
        if (status != Z_OK && status != Z_STREAM_END) {
            ap_log_rerror(APLOG_MARK, APLOG_NOERRNO|APLOG_ERR, d->r,
                          "mod_deflate: deflate failed: %d, %d",
                          flush, status);
            return -1;
        }

        if (d->zstream->avail_out == 0)
            redo = 1;

        nout = HUGE_STRING_LEN - d->zstream->avail_out;

        if (nout > 0)
            if (ap_internal_bwrite(fb, zbuf, nout) != nout) {
                ap_log_rerror(APLOG_MARK, APLOG_INFO, d->r,
                              "mod_deflate: ap_bwrite() failed");
                return -1;
            }

        if (flush == Z_FINISH && status == Z_STREAM_END)
            return 0;
    }

    return nbyte;
}

void deflate_end(BUFF *fb, int flag)
{
    struct gztrailer trailer;
    int zin, zout;
    deflate_rec *d = (deflate_rec *) fb->deflate;
    request_rec *r = d->r;

#ifdef MOD_DEFLATE_IDLE
    deflate_server_conf *conf = (deflate_server_conf *)
               ap_get_module_config(r->server->module_config, &deflate_module);
#endif

    ap_deflate_bwrite(fb, NULL, 0, DEFLATE_FINISH);

    zin = d->zstream->total_in;
    zout = d->zstream->total_out;

    /* write a gzip trailer */
    if (flag & B_GZIP) {
        trailer.crc32 = d->crc32;
        trailer.zlen = d->zstream->total_in;
        ap_internal_bwrite(fb, &trailer, sizeof(trailer));
        zout += sizeof(gzheader) + sizeof(trailer);
    }

    deflateEnd(d->zstream);

#ifdef MOD_DEFLATE_IDLE
    if (conf->idle > 0 && slot_num >= 0) {
        ap_sync_scoreboard_image();
        ap_scoreboard_image->servers[slot_num].deflate = 0; 
        ap_scoreboard_image->global.deflate_current--;
    }
#endif

    ap_table_set(r->notes, "defl_m", flag & B_DEFLATE ? "d" : "g");
    ap_table_set(r->notes, "defl_i", ap_psprintf(r->pool, "%d", zin));
    ap_table_set(r->notes, "defl_o", ap_psprintf(r->pool, "%d", zout));

    if (zout > 0) {
        int zint = zin / zout;
        int zfrac = (zin * 100 / zout) % 100;

        if ((zin * 1000 / zout) % 10 > 4)
            if (++zfrac > 99) {
                zint++;
                zfrac = 0;
            }

        ap_table_set(r->notes, "defl_r",
                     ap_psprintf(r->pool, "%d.%02d", zint, zfrac));
    }
}

static int deflate_content_type(request_rec *r, table *t)
{       
    const char   *type, *state;
    array_header *ta;

    if (r->content_type)
        type = r->content_type;
    else if (type = ap_table_get(r->headers_out, "Content-Type"))
        ;
    else
        type =  ap_default_type(r);

    if (!(state = ap_table_get(t, ap_get_token(r->pool, &type, 0)))
          || state[0] == '-')
        return 0;

    return 1;
}



static void *deflate_create_server_config(pool *p, server_rec *s)
{
    deflate_server_conf *conf = ap_pcalloc(p, sizeof(deflate_server_conf));

#ifdef MOD_DEFLATE_IDLE
    conf->idle = UNSET;
    conf->period = UNSET;
#endif

    return (void *)conf;
}

static void *deflate_merge_server_config(pool *p, void *base, void *new)
{
    deflate_server_conf *merged = ap_pcalloc(p, sizeof(deflate_server_conf));
    deflate_server_conf *parent = (deflate_server_conf *) base;
    deflate_server_conf *child = (deflate_server_conf *) new;

#ifdef MOD_DEFLATE_IDLE
    merged->idle = parent->idle != UNSET ? parent->idle : child->idle;
    merged->period = parent->period != UNSET ? parent->period : child->period;
#endif

    return (void *)merged;
}

static void *deflate_create_dir_config(pool *p, char *dir)
{
    deflate_dir_conf *conf = ap_pcalloc(p, sizeof(deflate_dir_conf));

    conf->enable = UNSET;
    conf->min_version = UNSET;
    conf->proxied = UNSET;
    conf->first = UNSET;
    conf->second = UNSET;
    conf->comp_level = UNSET;
    conf->length = UNSET;

    conf->types = ap_make_table(p, 10);
    ap_table_setn(conf->types, "text/html", "+");
    conf->disable_range = ap_make_array(p, 1, sizeof(deflate_agent));

    return (void *)conf;
}

static void *deflate_merge_dir_config(pool *p, void *base, void *new)
{
    int           i;
    array_header *ta;
    table_entry  *type;

    deflate_dir_conf *merged = ap_pcalloc(p, sizeof(deflate_dir_conf));
    deflate_dir_conf *parent = (deflate_dir_conf *) base;
    deflate_dir_conf *child = (deflate_dir_conf *) new;

    merge(merged, parent, child, enable);
    merge(merged, parent, child, min_version);
    merge(merged, parent, child, proxied);
    merge(merged, parent, child, first);
    merge(merged, parent, child, second);
    merge(merged, parent, child, comp_level);
    merge(merged, parent, child, length);

    merged->types = ap_copy_table(p, parent->types);
    ta = ap_table_elts(child->types);
    type = (table_entry *)ta->elts;
    for (i = 0; i < ta->nelts; i++)
        ap_table_setn(merged->types, type[i].key, type[i].val);

    merged->disable_range = ap_append_arrays(p, parent->disable_range,
                                                 child->disable_range);

    return (void *)merged;
}

static const char *set_http_version(cmd_parms *cmd, void *dummy, char *version)
{
    deflate_dir_conf *conf = (deflate_dir_conf *)dummy;

    if (strcmp(version, "1.0") == 0) {
        conf->min_version = HTTP_VERSION(1,0);
        return NULL;

    } else if (strcmp(version, "1.1") == 0) {
        conf->min_version = HTTP_VERSION(1,1);
        return NULL;

    } else {
        return "DeflateHTTP must be 1.0 or 1.1";
    }
}

static const char *set_comp_order(cmd_parms *cmd, void *dummy,
                                  char *one, char* two)
{
    deflate_dir_conf *conf = (deflate_dir_conf *)dummy;

    if (strcmp(one, "deflate") == 0) {
        conf->first = M_DEFLATE;
    } else if (strcmp(one, "gzip") == 0) {
        conf->first = M_GZIP;
    } else {
        return "DeflateOrder must has 'deflate' or 'gzip' values";
    }

    if (!two) {
        conf->second = 0;
        return NULL;
    }

    if (strcmp(two, "deflate") == 0) {
        conf->second = M_DEFLATE;
    } else if (strcmp(two, "gzip") == 0) {
        conf->second = M_GZIP;
    } else {
        return "DeflateOrder must has 'deflate' or 'gzip' values";
    }

    return NULL;
}

static const char *set_mime_types(cmd_parms *cmd, void *dummy, char *type)
{
    char *state;

    deflate_dir_conf *conf = (deflate_dir_conf *)dummy;

    if (strcasecmp(type, "-text/html") == 0)
        return "DeflateTypes: text/html can not be disabled";

    if (type[0] == '-') {
        state = "-";
        type++;

    } else {
        state = "+";
        if (type[0] == '+')
            type++;
    }

    ap_table_setn(conf->types, type, state);

    return NULL;
}

static const char *set_disable_range(cmd_parms *cmd, void *dummy, char *agent)
{
    deflate_dir_conf *conf = (deflate_dir_conf *)dummy;

    deflate_agent *disabled = ap_push_array(conf->disable_range);
    disabled->agent = agent;

    return NULL;
}

static const char *set_comp_level(cmd_parms *cmd, void *dummy, char *level)
{
    deflate_dir_conf *conf = (deflate_dir_conf *)dummy;

    int size = atoi(level);

    if (size > 0 && size < 10) {
        conf->comp_level = size;
        return NULL;

    } else {
        return "DeflateCompLevel must be between 1 and 9";
    }
}

static const char *set_min_length(cmd_parms *cmd, void *dummy, char *length)
{
    int size;

    deflate_dir_conf *conf = (deflate_dir_conf *)dummy;

    if ((size = atoi(length)) >= 0) {
        conf->length = size;
        return NULL;

    } else {
        return "DeflateMinLength must be more or equal to zero";
    }
}

static const char *set_min_idle(cmd_parms *cmd, void *dummy, char *idle)
{
#ifdef MOD_DEFLATE_IDLE
    int value;
    const char *err;

    deflate_server_conf *conf = (deflate_server_conf *)
             ap_get_module_config(cmd->server->module_config, &deflate_module);

    if ((err = ap_check_cmd_context(cmd, GLOBAL_ONLY)) != NULL)
        return err;
 
    value = atoi(idle);

    if (value >= 0 && value <= 100) {
        conf->idle = value;
        return NULL;

    } else {
        return "DeflateMinIdle must be between 0 and 100";
    }
#else
#ifdef MOD_DEFLATE_IDLE_SUPPORTED
    return "DeflateMinIdle requires configure option --with-idle-check";
#else
    return "DeflateMinIdle isn't supported on this platform";
#endif
#endif
}

static const char *set_idle_check(cmd_parms *cmd, void *dummy, char *period)
{
#ifdef MOD_DEFLATE_IDLE
    int value;
    const char *err;

    deflate_server_conf *conf = (deflate_server_conf *)
             ap_get_module_config(cmd->server->module_config, &deflate_module);

    if ((err = ap_check_cmd_context(cmd, GLOBAL_ONLY)) != NULL)
        return err;
 
    value = atoi(period);

    if (value > 0) {
        conf->period = value;
        return NULL;

    } else {
        return "DeflateIdleCheck must be more then 0";
    }
#else
#ifdef MOD_DEFLATE_IDLE_SUPPORTED
    return "DeflateIdleCheck requires configure option --with-idle-check";
#else
    return "DeflateIdleCheck is not supported on this platform";
#endif
#endif
}


static const command_rec deflate_cmds[] =
{
    {"DeflateEnable", ap_set_flag_slot,
     (void *)XtOffsetOf(deflate_dir_conf, enable),
     OR_FILEINFO, FLAG,
     "enable gzip/deflate encoding"},

    {"DeflateHTTP", set_http_version, NULL, OR_FILEINFO, TAKE1,
     "set request minimum HTTP version to allow gzip/deflate compression"},

    {"DeflateProxied", ap_set_flag_slot,
     (void *)XtOffsetOf(deflate_dir_conf, proxied),
     OR_FILEINFO, FLAG,
     "enable gzip/deflate encoding for proxied request"},

    {"DeflateDisableRange", set_disable_range, NULL, OR_FILEINFO, ITERATE,
     "disable byte range in response for specified user agent"},

    {"DeflateOrder", set_comp_order, NULL, OR_FILEINFO, TAKE12,
     "set priority gzip or deflate method"},

    {"DeflateTypes", set_mime_types, NULL, OR_FILEINFO, ITERATE,
     "set MIME types that can be encoded"},

    {"DeflateCompLevel", set_comp_level, NULL, OR_FILEINFO, TAKE1,
     "set gzip/deflate compression level from 1 to 9"},

    {"DeflateMinLength", set_min_length, NULL, OR_FILEINFO, TAKE1,
     "set minimum response's Content-Length to allow "
     "gzip/deflate compression in percent"},

    {"DeflateMinIdle", set_min_idle, NULL, RSRC_CONF, TAKE1,
     "set minimum system idle to allow gzip/deflate compression in percent"},

    {"DeflateIdleCheck", set_idle_check, NULL, RSRC_CONF, TAKE1,
     "set period to check minimum system idle to allow "
     "gzip/deflate compression in seconds"},

    {NULL}
};


module deflate_module =
{
    STANDARD_MODULE_STUFF,
    deflate_init,                     /* module initializer */
    deflate_create_dir_config,        /* per-directory config creator */
    deflate_merge_dir_config,         /* dir config merger */
    deflate_create_server_config,     /* server config creator */
    deflate_merge_server_config,      /* server config merger */
    deflate_cmds,                     /* command table */
    NULL,                             /* [9] list of handlers */
    NULL,                             /* [2] filename-to-URI translation */
    NULL,                             /* [5] check/validate user_id */
    NULL,                             /* [6] check user_id is valid *here* */
    NULL,                             /* [4] check access by host address */
    NULL,                             /* [7] MIME type checker/setter */
    NULL,                             /* [8] fixups */
    NULL,                             /* [10] logger */
    NULL,                             /* [3] header parser */
    NULL,                             /* process initializer */
    NULL,                             /* process exit/cleanup */   
    deflate_post_read,                /* [1] post read_request handling */
}; 
