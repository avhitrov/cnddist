/* ====================================================================
 * Copyright (c) 1995 The Apache Group.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the Apache Group
 *    for use in the Apache HTTP server project (http://www.apache.org/)."
 *
 * 4. The names "Apache Server" and "Apache Group" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission.
 *
 * 5. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the Apache Group
 *    for use in the Apache HTTP server project (http://www.apache.org/)."
 *
 * THIS SOFTWARE IS PROVIDED BY THE APACHE GROUP ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE APACHE GROUP OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Group and was originally based
 * on public domain software written at the National Center for
 * Supercomputing Applications, University of Illinois, Urbana-Champaign.
 * For more information on the Apache Group and the Apache HTTP server
 * project, please see <http://www.apache.org/>.
 *
 */


 /* Module for support different cyrillic code pages
  * such us: koi8-r cp1251 (MS windows) cp866 (alt) iso-8859-5
  * Dm. Kryukov, Stack Ltd. <dvk@stack.serpukhov.su>
  * 96/02/15
  * This is not independent module, it must be used with my patch
  * to file http_protocol.c and with compilation key -DRUSSIAN_APACHE
  * 
  * This module was rewriten from scratch in 1997 by Alex Tutubalin <lexa@lexa.ru>
  * Many features was added and several bugs eliminated.
  * See http://apache.lexa.ru for details
  *
  * Copyright (C) Alex Tutubalin 1997-2001
  */

#ifndef MOD_CHARSET_H
#define MOD_CHARSET_H
#ifndef RUSSIAN_APACHE
#error You MUST specify -DRUSSIAN_APACHE compilation flag in your Configuration
#endif

#define MOD_CHARSET_VERSION "rus/PL30.9"
#define MOD_CHARSET_MAGIC   19981025
#define MOD_CHARSET_SELECTION_RULES 6 /* Number of different
					 CharsetSelectionRules */
#define MOD_CHARSET_DEFAULT_CHAR 0x20 /* character to put instead of
					 \x00 */


typedef struct
{
  char *charset;
  int  port;
} portlist_t;


typedef struct {
    char *real;
    char *fake;
    int redir_status;		/* 301, 302, 303, 410, etc */
} charset_alias_entry_t;

typedef struct {
    array_header *charset_redirects;
} charset_server_conf_t;

typedef struct {
  char *typename;
  char len;
} processed_type_t;

typedef struct {
  char *accept_string;
  char *agent_substring;
} broken_accept_t;

typedef struct {
  char *charset;
  char *server;
  int  port;
  char *prefix;
} charset_redirect_t;

typedef struct 
{
  array_header *charset_tables;
  unsigned char *emptytbl;
  char  *charset_default;
  char  *charset_source;
  table *charset_aliases;
  table *agent_charset;
  table *charset_priority;
  table *charset_exts;
  table *bad_agent;
  array_header *auto_redirects;
  array_header *normalize_types;
  array_header *portlist;
  array_header *processed_types;
  array_header *broken_accepts;
  charset_redirect_t *picture_url;
  int   redir_pic_minsize;
  int    selection_rules[MOD_CHARSET_SELECTION_RULES];
  int reject_error;
  int matchlang;
  int maxprio;
  int turnoff;
  int recode_headers;
  int recode_filenames;
  int override_expires;
  int strict_names;
  int multipart_forms;
  int disable_expires;
  int process_in,process_out;
  int disable_accept;
  int use_unparseduri;
  int no_redirect_defaults;
  array_header *redirects;
} charset_dir_t;


typedef struct recode_table_t_z
{
  char *namefrom;
  char *nameto;
  unsigned char *convtbl_ptr; /* from -> to */
  unsigned char *revtbl_ptr;
  int   flags;
  struct recode_table_t_z *next;
}recode_table_t;

typedef struct 
{
  char *tablename;
  char *lang;
  recode_table_t *recode_tables;
  int  flags;
} charset_table_t;


/* values of charset_table_t->flags */
#define MOD_CHARSET_NO_CHARSETNAME		1


enum 
{
  sNotused = 1,
  sPortnumber,
  sHostname,
  sDirprefix,
  sUseragent,
  sURIHostname,
  sEnvVariable
} selection_rules_t;


#ifdef MODCHARSET_CORE

enum 
{
  mUnknown = 0,
    mAcceptCharset,
    mDirprefix,
    mHostname,
    mURIHostname,
    mPortnumber,
    mEnvVariable,
    mUseragent,
    mDefault,
    mFirstInList
} det_method_t;

char *det_method_names[]=
{
  "Unknown",
  "AcceptCharset",
  "Dirprefix",
  "Hostname",
  "URIHostname",
  "Portnumber",
  "EnvVariable",
  "UserAgent",
  "Default",
  "FirstInList"
};

#endif




API_EXPORT(int) ra_calc_wide_len (const unsigned char *buf, const int len,
				  wide_table_t *tbl);




API_EXPORT(void)
ra_convert_by_table_esc(const unsigned char *buf, const unsigned int len,
			unsigned char ** result, unsigned int* rlen,
			const unsigned char *recode_table, int wide,
			ap_pool *p, local_buf_t *localdata);

API_EXPORT(void)
ra_convert_by_table(const  unsigned char *buf, const unsigned int len,
		    unsigned char ** result, unsigned int* rlen,
		    const unsigned char *recode_table, int wide,
		    ap_pool *p, local_buf_t *localdata);


API_EXPORT(void)
ra_in_place_convert_by_table( unsigned char *buf, const unsigned int len,
			     const unsigned char *recode_table);

#endif
