#define VERSION "LIBTIFF, Version 3.4beta024\nCopyright (c) 1988-1995 Sam Leffler\nCopyright (c) 1991-1995 Silicon Graphics, Inc."
