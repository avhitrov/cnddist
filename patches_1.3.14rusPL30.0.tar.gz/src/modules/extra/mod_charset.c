/* ====================================================================
 * Copyright (c) 1995 The Apache Group.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the Apache Group
 *    for use in the Apache HTTP server project (http://www.apache.org/)."
 *
 * 4. The names "Apache Server" and "Apache Group" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission.
 *
 * 5. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the Apache Group
 *    for use in the Apache HTTP server project (http://www.apache.org/)."
 *
 * THIS SOFTWARE IS PROVIDED BY THE APACHE GROUP ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE APACHE GROUP OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Group and was originally based
 * on public domain software written at the National Center for
 * Supercomputing Applications, University of Illinois, Urbana-Champaign.
 * For more information on the Apache Group and the Apache HTTP server
 * project, please see <http://www.apache.org/>.
 *
 */


 /* Module for support different cyrillic code pages
  * such us: koi8-r cp1251 (MS windows) cp866 (alt) iso-8859-5
  * Dm. Kryukov, Stack Ltd. <dvk@stack.serpukhov.su>
  * 96/02/15
  * This is not independent module, it must be used with my patch
  * to file http_protocol.c and with compilation key -DRUSSIAN_APACHE
  * 
  * This module was rewriten from scratch in 1997 by Alex Tutubalin <lexa@lexa.ru>
  * Many features was added and several bugs eliminated.
  * See http://apache.lexa.ru for details
  *
  * Copyright (C) Alex Tutubalin 1997-1999
  */

/*
 * Module definition information - the part between the -START and -END
 * lines below is used by Configure. This could be stored in a separate
 * instead.
 *
 * MODULE-DEFINITION-START
 * Name: charset_module
 * ConfigStart
   CFLAGS="$CFLAGS -DRUSSIAN_APACHE"
 * ConfigEnd
 * MODULE-DEFINITION-END
 */


#include "httpd.h"
#include "ap_alloc.h"
#include "http_config.h"
#include "http_main.h"
#include "http_core.h"
#include "http_protocol.h"
#include "http_request.h"
#include "http_log.h"


#define MODCHARSET_CORE 1
#include "mod_charset.h"


#define CMDCONST static const

/* flags for set_charset routine */
#define SCH_CAN_CACHE		1
#define SCH_HAVE_UA		2 /* We actually do not use it */
#define SCH_BY_UA		4
#define SCH_BY_ACCEPT		8


#define PROCESS_ALL (1<<(METHODS))
#define PROCESS_GET (1<<(M_GET))
#define PROCESS_POST (1<<(M_POST))
#define PROCESS_PUT (1<<(M_PUT))
#define PROCESS_NONE (1<<(METHODS+1))
#define FL_DEFAULT		0
#define FL_OFF			1
#define FL_ON			2
#define RECODE_ALLOC_CHUNK	8192

/*
typedef  struct  {
  int len;
  unsigned char *data;
} local_buffer_t;
*/

module charset_module;



static int default_rule_list[MOD_CHARSET_SELECTION_RULES]={sPortnumber,sHostname,
				      sURIHostname,sEnvVariable,
				      sDirprefix,sUseragent};


static char* read_table(FILE *fp, unsigned char *tab1, unsigned char *tab2);
static void  set_charset(charset_table_t *, request_rec *, charset_dir_t *, int);
static int   have_different_charsets(charset_dir_t *dirconf);
static void  check_recode_buf(ap_pool *p,local_buf_t *buf, const unsigned int len);
static int   parse_urlprefix (char *prefix, ap_pool *p, charset_redirect_t *redir);
static array_header *merge_redirect_tables(ap_pool *p, array_header *base, array_header *override);
static void  add_redirect_to_table(array_header *h, charset_redirect_t *rd);


static void *
create_charset_config (ap_pool *p, server_rec *s)
{
    charset_server_conf_t *a =
      (charset_server_conf_t *)ap_pcalloc (p, sizeof(charset_server_conf_t));
    a->charset_redirects = ap_make_array (p, 20, sizeof(charset_alias_entry_t));
    return a;
}

static void *
merge_charset_config (ap_pool *p, void *basev, void *overridesv)
{
    charset_server_conf_t *a =
	(charset_server_conf_t *)ap_pcalloc (p, sizeof(charset_server_conf_t));
    charset_server_conf_t *base = (charset_server_conf_t *)basev,
	*overrides = (charset_server_conf_t *)overridesv;

    a->charset_redirects = ap_append_arrays (p, overrides->charset_redirects, 
					  base->charset_redirects);
    return a;
}



static void* 
create_charset_dir_conf(ap_pool *p,char *dummy)
{
  charset_dir_t *cp=(charset_dir_t*)ap_pcalloc(p,sizeof(charset_dir_t));
  processed_type_t *tp;
  int i;
  cp->charset_tables = ap_make_array(p,10,sizeof(charset_table_t));
  cp->emptytbl = ap_palloc(p,TABLECHARS);
  for(i=0;i<TABLECHARS;i++) cp->emptytbl[i] = i?i:MOD_CHARSET_DEFAULT_CHAR;

  cp->redirects = ap_make_array (p, 10, sizeof(charset_alias_entry_t));
  cp->broken_accepts = ap_make_array(p,10,sizeof(broken_accept_t));

  cp->processed_types = ap_make_array(p,5,sizeof (processed_type_t));
  tp=ap_push_array(cp->processed_types);
  tp->typename="text/";
  tp->len = 5;

  cp->normalize_types = ap_make_array(p,5,sizeof (processed_type_t));

  cp->auto_redirects = ap_make_array(p,5,sizeof(charset_redirect_t));

  cp->charset_aliases = ap_make_table(p,5);
  cp->bad_agent	= ap_make_table(p,5);
  cp->charset_priority=ap_make_table(p,5);
  cp->agent_charset = ap_make_table(p,20);
  cp->charset_exts = ap_make_table(p,20);

  cp->picture_url = NULL;
  cp->redir_pic_minsize = 0;
  cp->portlist = ap_make_array(p,5,sizeof(portlist_t));
  cp->charset_default = NULL;
  cp->reject_error =  cp->maxprio = cp->matchlang =  cp->turnoff = 
    cp->recode_headers = cp->recode_filenames = 
    cp->override_expires = cp->strict_names =
    cp->multipart_forms = cp->disable_expires
    = cp->disable_accept = cp->use_unparseduri =
    cp->no_redirect_defaults 
    = FL_DEFAULT;
  cp->process_in = cp->process_out = 0;
  memset(cp->selection_rules,0,MOD_CHARSET_SELECTION_RULES*sizeof(cp->selection_rules[0]));
  return cp;
}


static void * 
merge_charset_dir_conf (ap_pool *p, void *basev, void *overridesv)
{
  charset_dir_t *a = (charset_dir_t *)ap_pcalloc (p, sizeof(charset_dir_t));
  charset_dir_t *base = (charset_dir_t *)basev,
    *over = (charset_dir_t *)overridesv;


  a->redirects = ap_append_arrays (p, over->redirects, base->redirects);

#define override_array(tablename) ((over->tablename->nelts > 0)?\
                                    ap_copy_array(p,over->tablename):\
                                    ap_copy_array(p,base->tablename))

  a->charset_tables= override_array(charset_tables);
  a->portlist = override_array(portlist);
  a->processed_types = override_array(processed_types);
  a->normalize_types = override_array(normalize_types);
  a->broken_accepts = override_array(broken_accepts);
#undef override_array

  a->auto_redirects = merge_redirect_tables(p,base->auto_redirects,over->auto_redirects);
    
  a->emptytbl = base->emptytbl;

#define override_table(tablename) (ap_is_empty_table(over->tablename))?\
  ap_copy_table(p,base->tablename):\
    ap_copy_table(p,over->tablename)

  a->charset_aliases	=override_table(charset_aliases);
  a->bad_agent		=override_table(bad_agent);
  a->agent_charset	=override_table(agent_charset);
  a->charset_exts	=override_table(charset_exts);
  a->picture_url	=over->picture_url ? over->picture_url : base->picture_url;
#undef override_table
  if(!ap_is_empty_table(over->charset_priority))
    {
      a->charset_priority = ap_copy_table(p,over->charset_priority);
      a->maxprio = over->maxprio;
    }
  else
    {
      a->charset_priority = ap_copy_table(p,base->charset_priority);
      a->maxprio = base->maxprio;
    }
  
      
#define overlay_flag(flag) over->flag?over->flag:base->flag
  a->redir_pic_minsize =overlay_flag(redir_pic_minsize);
  a->charset_default=overlay_flag(charset_default);
  a->charset_source=overlay_flag(charset_source);
  a->reject_error = overlay_flag(reject_error);
  a->matchlang = overlay_flag(matchlang);
  a->turnoff = overlay_flag(turnoff);
  a->recode_headers = overlay_flag(recode_headers);
  a->recode_filenames = overlay_flag(recode_filenames);
  a->override_expires = overlay_flag(override_expires);
  a->strict_names = overlay_flag(strict_names);
  a->multipart_forms = overlay_flag(multipart_forms);
  a->disable_expires = overlay_flag(disable_expires);
  a->disable_accept = overlay_flag(disable_accept);
  a->process_in = overlay_flag(process_in);
  a->process_out = overlay_flag(process_out);
  a->use_unparseduri = overlay_flag(use_unparseduri);
  a->no_redirect_defaults = overlay_flag(no_redirect_defaults);
#undef overlay_flag
  if(over->selection_rules[0] != 0)
    memcpy(a->selection_rules,over->selection_rules,
	   MOD_CHARSET_SELECTION_RULES*sizeof(over->selection_rules[0]));
  else
    memcpy(a->selection_rules,base->selection_rules,
	   MOD_CHARSET_SELECTION_RULES*sizeof(base->selection_rules[0]));
    
  return a;
}


/* ============ table lookup utilities ================= */

/* 
   ���������� ������������, �������� ������� ��������� � ������� 
   ��������� bname 
   ���� strict != 0, �� ��������� ������ bname ����� match ������ ����
   ��� \0, ��� �������� �� ������ delim
*/

static charset_table_t* 
strncmp_get_chtable(charset_dir_t *s,const char *bname,int strict, char *delim)
{
  array_header *t = s->charset_tables;
  charset_table_t *p = (charset_table_t*)t->elts;
  int len;
  int i;
  for (i=0;i<t->nelts;i++)
    {
      len = strlen(p[i].tablename);
      if(!strncasecmp(bname,p[i].tablename,len))
	if(!strict || bname[len] == '\0' ||  strchr(delim,bname[len]))
	  return p+i;
    }
  return NULL;
}

/* ���������� ������������, �������� ������� ��������� � name */
static charset_table_t* 
get_chtable(charset_dir_t *s, const char *name)
{
  array_header *t = s->charset_tables;
  charset_table_t *p = (charset_table_t*)t->elts;
  int i;
  for (i=0;i<t->nelts;i++)
      if(!strcasecmp(p[i].tablename,name))
	return p+i;
  return NULL;
}


static recode_table_t*
new_recode_table(ap_pool *p, char *namefrom,char *nameto, 
		 unsigned char *ctbl, unsigned char *rtbl,int flags)
{
  recode_table_t *r = ap_pcalloc(p,sizeof(recode_table_t));
  r->namefrom = namefrom;
  r->nameto = nameto;
  r->convtbl_ptr = ctbl;
  r->revtbl_ptr = rtbl;
  r->flags  = flags;
  r->next = NULL;
  return r;
}


static recode_table_t*
find_recode_table(recode_table_t *l, const char* from_name)
{
  recode_table_t *z = l;
  while(z)
    if(!strcasecmp(z->namefrom,from_name))
      return z;
    else
      z=z->next;

  return NULL;
}

/* 
   ���������� ��������� �� ������� � from_name == name 
   � ������ list. �������� ������� ������������� ��� ���������� 
*/
static recode_table_t*
append_recode_table(ap_pool *p, recode_table_t *list, char *from_name,
		    unsigned char *ctbl, unsigned char *rtbl,int flags)
{

  recode_table_t *z = list;
  while(1)
    {
      if(!strcasecmp(z->namefrom,from_name)) 
	{
	  z->convtbl_ptr = ctbl;
	  z->revtbl_ptr  = rtbl;
	  z->flags|=flags;
	  return z;
	}
      if(z->next)
	z=z->next;
      else
	return z->next = new_recode_table(p,from_name,list->nameto,
					  ctbl,rtbl,flags);
    }
}

static int 
get_selection_rule(const char *word)
{
  if(!word || !*word) return 0;
  if(!strcasecmp(word,"Portnumber")) return sPortnumber;
  if(!strcasecmp(word,"Hostname")) return sHostname;
  if(!strcasecmp(word,"URIHostname")) return sURIHostname;
  if(!strcasecmp(word,"EnvVariable")) return sEnvVariable;
  if(!strcasecmp(word,"Dirprefix")) return sDirprefix;
  if(!strcasecmp(word,"Useragent")) return sUseragent;
  return 0;
}


/* =============== Configuration commands ============= */

/*
  CharsetDecl CharsetName Lang
 */

CMDCONST char *
add_charset_decl(cmd_parms *cmd, charset_dir_t *dc,
		 char *name, char *lang, char *flags)
{ 
  charset_table_t *t = ap_push_array(dc->charset_tables);
  t->tablename = name;
  t->lang = lang;
  t->recode_tables = new_recode_table(cmd->pool,name,name,dc->emptytbl,
				      dc->emptytbl,0);
  t->flags=0;
  if(flags && (strchr(flags,'S') || strchr(flags,'s'))){
    t->flags |= MOD_CHARSET_NO_CHARSETNAME;
  }
  return NULL;
}

/*
  CharsetRecodeTable CharsetName1 CharsetName2 table1_2 [table2_1] {FLAGS}
*/
#if 1 

/*
 1. �������� ��������� �������� ������-�������� ������� �������
      (�������� � ������������� ������ ��������)
 2. ������ �������������� ���������, ������������ read_table.
*/

CMDCONST char *
add_charset_recode_table(cmd_parms *cmd, charset_dir_t *dc, const char *arg)
{
  char *cset1,*cset2,*table1_2, *table2_1;
  unsigned char *ctable,*rtable;
  FILE *f1_2,*f2_1 = NULL;
  charset_table_t *ct1,*ct2;
  char* pszResult = NULL;

  cset1 = ap_getword_conf(cmd->pool,&arg);
  cset2 = ap_getword_conf(cmd->pool,&arg);
  table1_2 = ap_getword_conf(cmd->pool,&arg);
  if(!cset1 || !cset2 || !table1_2 || !*cset1 || !*cset2 || !*table1_2)
    return "Invalid CharsetRecodeTable directive";
  ct1 = get_chtable(dc,cset1); /* CharsetDecl: cset1 */
  ct2 = get_chtable(dc,cset2);
  if(!ct1 || !ct2)
    return "Unknown Charset name in CharsetRecodeTable direcive";
  if ((f1_2=ap_pfopen(cmd->pool,ap_server_root_relative(cmd->pool, table1_2),"r")) 
      == NULL)
    return "CharsetTable: Can't open output table file";

  if((table2_1=ap_getword_conf(cmd->pool,&arg)) && *table2_1 && 
     (f2_1=ap_pfopen(cmd->pool,
		  ap_server_root_relative(cmd->pool, table2_1),"r")) == NULL)
    return "CharsetTable: Can't open input table file";
  
  
  ctable = ap_palloc(cmd->pool,TABLECHARS);
  rtable = ap_palloc(cmd->pool,TABLECHARS);

  if( f2_1 )
  {
      /* ������ ��� ������� ��������                   */
      /* �� ����� ������������� ������������ ��������! */
      pszResult = read_table(f1_2,ctable,NULL);
      ap_pfclose(cmd->pool,f1_2);

      if( !pszResult )
        pszResult = read_table(f2_1,rtable,NULL);
      
      ap_pfclose(cmd->pool,f2_1);
  }
  else
  {
      /* ������ ������ ���� ������� ��������                  */
      /* �������� ������� �������� ������������ ������������� */
      pszResult = read_table(f1_2,ctable,rtable);
      ap_pfclose(cmd->pool,f1_2);
  }
  
  append_recode_table(cmd->pool,ct2->recode_tables,cset1,ctable,rtable,0);
  append_recode_table(cmd->pool,ct1->recode_tables,cset2,rtable,ctable,0);

  return pszResult;
}


#else

CMDCONST char *
add_charset_recode_table(cmd_parms *cmd, charset_dir_t *dc, const char *arg)
{
  char *cset1,*cset2,*table1_2, *table2_1;
  unsigned char *ctable,*rtable;
  FILE *f1_2,*f2_1 = NULL;
  charset_table_t *ct1,*ct2;

  cset1 = ap_getword_conf(cmd->pool,&arg);
  cset2 = ap_getword_conf(cmd->pool,&arg);
  table1_2 = ap_getword_conf(cmd->pool,&arg);
  if(!cset1 || !cset2 || !table1_2 || !*cset1 || !*cset2 || !*table1_2)
    return "Invalid CharsetRecodeTable directive";
  ct1 = get_chtable(dc,cset1); /* CharsetDecl: cset1 */
  ct2 = get_chtable(dc,cset2);
  if(!ct1 || !ct2)
    return "Unknown Charset name in CharsetRecodeTable direcive";
  if ((f1_2=ap_pfopen(cmd->pool,ap_server_root_relative(cmd->pool, table1_2),"r")) 
      == NULL)
    return "CharsetTable: Can't open output table file";

  if((table2_1=ap_getword_conf(cmd->pool,&arg)) && *table2_1 && 
     (f2_1=ap_pfopen(cmd->pool,
		  ap_server_root_relative(cmd->pool, table2_1),"r")) == NULL)
    return "CharsetTable: Can't open input table file";
  
  
  ctable = ap_palloc(cmd->pool,TABLECHARS);
  rtable = ap_palloc(cmd->pool,TABLECHARS);
  read_table(f1_2,ctable,rtable);
  ap_pfclose(cmd->pool,f1_2);
  if(f2_1)
    {
      read_table(f2_1,rtable,NULL);
      ap_pfclose(cmd->pool,f2_1);
    }
  
  append_recode_table(cmd->pool,ct2->recode_tables,cset1,ctable,rtable,0);
  append_recode_table(cmd->pool,ct1->recode_tables,cset2,rtable,ctable,0);

  return NULL;
}

#endif

/* 
   CharsetWideRecodeTable
*/
CMDCONST char *
add_wide_recode_table (cmd_parms *cmd, charset_dir_t *dc, 
		       char *charsetfrom, char *charsetto, 
		       char *filename)
{
    unsigned char *ptrs[TABLECHARS];
    unsigned char string[MAX_STRING_LEN],t[2];
    unsigned  src,dst,len,i;
    charset_table_t *ct1,*ct2;
    wide_table_t *wtable;
    ap_pool *lpool = ap_make_sub_pool(cmd->pool);
    FILE *f;
    /* pass one - read tablefile */
    for(i=0;i<TABLECHARS;i++)
	ptrs[i] = NULL;

    ct1 = get_chtable(dc,charsetfrom); /* CharsetDecl: cset1 */
    ct2 = get_chtable(dc,charsetto);
    if(!ct1 || !ct2)
	return "Unknown Charset name in CharsetRecodeTable direcive";

  
    if((f = ap_pfopen(cmd->pool,ap_server_root_relative(cmd->pool, filename),"r"))
       ==NULL)
	{
	    return "Recode table file is unreadable";
	}

    while (fgets(string,MAX_STRING_LEN,f) != NULL)
	{
	    unsigned char *p;
	    unsigned char *sptr = string;
	    while(*sptr && isspace(*sptr)) sptr++;
	    if(!*sptr) continue; /* empty line */
	    if(*sptr == '#') continue; /* comment */
	    sptr = strtok(sptr," \t");
	    p = strtok(NULL," \t");
	    if(sptr && p)
		{
		    if (sptr[0]=='0' && sptr[1]=='x')
			sscanf(sptr,"0x%x",&src);
		    else if (sptr[1])
			src=atoi(sptr); /* one-byte numbers treated as symbols! */
		    else
			src=*sptr;
		    if (p[0]=='0' && p[1]=='x')
			{
			    sscanf(p,"0x%x",&dst);
			    t[0]=dst;t[1]='\0';
			}
		    else 
			{
			    t[0]=0;
			    strtok(p," \t\n\r");
			}
		    if (src < 256)
			{
			    if(t[0]) 
				ptrs[src] = ap_pstrdup(lpool,t);
			    else
				{
				    ptrs[src] = ap_pstrdup(lpool,p);
				}
			}
		}
	}
    /* pass 2 - count lengths */
    wtable=ap_palloc(cmd->pool,sizeof(wide_table_t));
    for (i=len=0;i<TABLECHARS;i++)
	{
	    wtable->len[i] = wtable->offsets[i] =0;
	    if(ptrs[i])
		len+= (wtable->len[i] = strlen(ptrs[i]));
	    else
		len++; /* character itself */
	}

    wtable->table=ap_palloc(cmd->pool,len);
    len = 0;
    for(i=0;i<TABLECHARS;i++) 
	{
	    if(wtable->len[i])
		{
		    memcpy(wtable->table+len,ptrs[i],wtable->len[i]);
		    wtable->offsets[i] = len;
		    len+=wtable->len[i];
		}
	    else 
		{
		    wtable->len[i] = 1;
		    wtable->offsets[i] = len;
		    wtable->table[len] = i;
		    len++;
		}
	}
    append_recode_table(cmd->pool,ct2->recode_tables,charsetfrom,
			(unsigned char *)wtable,dc->emptytbl,RA_WIDE_CHARS_SC);
  
    return NULL;
}


/*
  CharsetAlias charset alias1 alias2
*/
CMDCONST char *
add_charset_alias(cmd_parms *cmd, charset_dir_t *dc,
		char *name, char *alias)
{
  ap_table_set(dc->charset_aliases,alias,name);
  return NULL;
}

/*
  NativeCharset charset
*/
CMDCONST char *
add_charset_default (cmd_parms *cmd, charset_dir_t *dc, char *name)
{
  dc->charset_default = name;
  return NULL;
}
/*
  CharsetSource charset
*/

CMDCONST char *
add_charset_source(cmd_parms *cmd, charset_dir_t *dc, char *name)
{
  dc->charset_source = name;
  return NULL;
}

CMDCONST char *
add_ext_charset(cmd_parms *cmd, charset_dir_t *dc, char *charset, char *ext)
{
  if(*ext=='.') ext++;
  ap_table_set(dc->charset_exts,ext,charset);
  return NULL;
}

/*
  CharsetPriority cset1 cset2 cset3 ...
*/
CMDCONST char *
add_charset_priority (cmd_parms *cmd, charset_dir_t *dc, char *cset)
{
  char *prio = ap_palloc(cmd->pool,2);
  prio[1] = 0;
  prio[0] = ++dc->maxprio;
  ap_table_set(dc->charset_priority,cset,prio);
  return dc->maxprio<255?NULL:"Too many charsets in Charset-priority list";
}

/*
  AgentCharset charset agent1 agent2 ...
 */
CMDCONST char *
add_agent_charset(cmd_parms *cmd,charset_dir_t *dc, char *cset, char *agent)
{
  ap_table_set(dc->agent_charset,agent,cset);
  return NULL;

}

/*
  BadAgent agent1 agent2 agent3...
 */
CMDCONST char *
add_bad_agent(cmd_parms *cmd,charset_dir_t *dc, char *agent)
{
  ap_table_set(dc->bad_agent,agent," ");
  return NULL;
}


/* CharsetErrReject on|off */
CMDCONST char *
add_reject_error_charset(cmd_parms *cmd, charset_dir_t *dc, int flag) 
{
  dc->reject_error=flag?FL_ON:FL_OFF;
  return NULL;
}
/* CharsetUseMultiViews on|off */
CMDCONST char *
add_charset_matchlang(cmd_parms *cmd, charset_dir_t *dc, int flag) 
{
  if((int)cmd->info==1) 
    ap_log_error(APLOG_MARK,APLOG_WARNING,cmd->server,
		 "CharsetMatchLanguage is now deprecated, use CharsetUseMultiViews instead");
  dc->matchlang=flag?FL_ON:FL_OFF;
  return NULL;
}

/* CharsetRecodeHeaders on|off */
CMDCONST char *
add_charset_recode_headers(cmd_parms *cmd, charset_dir_t *dc, int flag) 
{
  dc->recode_headers=flag?FL_ON:FL_OFF;
  return NULL;
}
/* CharsetRecodeFilenames on|off */
CMDCONST char *
add_charset_recode_filenames(cmd_parms *cmd, charset_dir_t *dc, int flag) 
{
  dc->recode_filenames=flag?FL_ON:FL_OFF;
  return NULL;
}
/* CharsetOverrideExpires on|off */
CMDCONST char *
add_charset_override_expires(cmd_parms *cmd, charset_dir_t *dc, int flag) 
{
  dc->override_expires=flag?FL_ON:FL_OFF;
  return NULL;
}
/* CharsetDisable on|off */
CMDCONST char *
add_charset_turnoff(cmd_parms *cmd, charset_dir_t *dc, int flag) 
{
  if((int)cmd->info==1) 
    ap_log_error(APLOG_MARK,APLOG_WARNING,cmd->server,
		 "CharsetTurnOff is now deprecated, use CharsetDisable instead");
  dc->turnoff=flag?FL_ON:FL_OFF;
  return NULL;
}
/* CharsetStrictURIMatch on|off */
CMDCONST char *
add_charset_stricturi(cmd_parms *cmd, charset_dir_t *dc, int flag) 
{
  dc->strict_names=flag?FL_ON:FL_OFF;
  return NULL;
}
/* CharsetRecodeMultipartForms on|off */
CMDCONST char *
add_charset_mpforms(cmd_parms *cmd, charset_dir_t *dc, int flag) 
{
  dc->multipart_forms=flag?FL_ON:FL_OFF;
  return NULL;
}

/* CharsetDisableForcedExpires on|off */
CMDCONST char *
add_disable_expires(cmd_parms *cmd, charset_dir_t *dc, int flag) 
{
  dc->disable_expires=flag?FL_ON:FL_OFF;
  return NULL;
}

/* CharsetDisableAcceptCharset on|off */
CMDCONST char *
add_disable_accept(cmd_parms *cmd, charset_dir_t *dc, int flag) 
{
  dc->disable_accept=flag?FL_ON:FL_OFF;
  return NULL;
}



CMDCONST char*
add_charset_selection_rules(cmd_parms *cmd, charset_dir_t *dc, const char *arg)
{
  int i,j,rule;
  char *word;
  
  if(!(word=ap_getword_conf(cmd->pool,&arg)) || !*word)
    {
     memset(dc->selection_rules,0,sizeof(dc->selection_rules[0])*MOD_CHARSET_SELECTION_RULES);
     dc->selection_rules[0] = sNotused;
     return NULL;
    }
  if(0==(rule=get_selection_rule(word)))
    return "Invalid selection rule name";
  else
    dc->selection_rules[0]=rule;
  for(i=1;i<MOD_CHARSET_SELECTION_RULES;i++)
    {
      if(!(word=ap_getword_conf(cmd->pool,&arg)) || !*word) return NULL;
      if(0==(rule=get_selection_rule(word)))
	return "Invalid selection rule name";
      for(j=0;j<i;j++)
	if(dc->selection_rules[j]==rule)
	  return "Duplicated SelectionRule name";
      dc->selection_rules[i]=rule;
    }
  return NULL;
}
	    
/*
  CharsetByPort charset port
 */

CMDCONST char *
add_charset_byport(cmd_parms *cmd, charset_dir_t *dc,char *cset, char *port)
{ 
  int p = atoi(port);
  portlist_t *t;
  if(!p) 
    return "Port must be numeric and greater then zero";
  t = ap_push_array(dc->portlist);
  t->charset = cset;
  t->port = p;
  return NULL;
}


CMDCONST char *
charset_add_redirect(cmd_parms *cmd, charset_dir_t *dirconf, 
				char *arg1, char *arg2, char *arg3)
{
    charset_alias_entry_t *new;
    server_rec *s = cmd->server;
    charset_server_conf_t *serverconf =
        (charset_server_conf_t *)ap_get_module_config(s->module_config,&charset_module);
    int status = (int)cmd->info;
    char *f = arg2;
    char *url = arg3;

    if (!strcasecmp(arg1, "gone"))
	status = HTTP_GONE;
    else if (!strcasecmp(arg1, "permanent"))
	status = HTTP_MOVED_PERMANENTLY;
    else if (!strcasecmp(arg1, "temp"))
	status = HTTP_MOVED_TEMPORARILY;
    else if (!strcasecmp(arg1, "seeother"))
	status = HTTP_SEE_OTHER;
    else if (isdigit(*arg1))
	status = atoi(arg1);
    else {
	f = arg1;
	url = arg2;
    }

    if (ap_is_HTTP_REDIRECT(status)) {
      if (!url) return "URL to redirect to is missing";
    }else {
      if (url) return "Redirect URL not valid for this status";
    }

    if ( cmd->path )
        new = ap_push_array (dirconf->redirects);
    else
        new = ap_push_array (serverconf->charset_redirects);

    new->fake = f; new->real = url;
    new->redir_status = status;
    return NULL;
}

CMDCONST char *
add_proctype (cmd_parms *cmd, charset_dir_t *dc, char *name)
{
  processed_type_t *tp;
  tp=ap_push_array(dc->processed_types);
  tp->typename=name;
  tp->len = strlen(name);
  return NULL;
}

CMDCONST char *
add_brokaccept (cmd_parms *cmd, charset_dir_t *dc, char *agent, char *accept)
{
  broken_accept_t *bp;
  bp=ap_push_array(dc->broken_accepts);
  bp->agent_substring = agent;
  bp->accept_string = accept;
  return NULL;
}


/*
  CharsetRecodeMethodsIn GET PUT POST ALL NONE
 */
CMDCONST char *
add_charset_methods_in(cmd_parms *cmd,charset_dir_t *dc, char *method)
{
  if(!strcasecmp(method,"get"))
    dc->process_in |= PROCESS_GET;
  else if (!strcasecmp(method,"POST"))
    dc->process_in |= PROCESS_POST;
  else if (!strcasecmp(method,"PUT"))
    dc->process_in |= PROCESS_PUT;
  else if (!strcasecmp(method,"NONE"))
    dc->process_in = PROCESS_NONE;
  else if (!strcasecmp(method,"ALL"))
    dc->process_in = PROCESS_ALL;
  else 
    return "Usage: CharsetRecodeMethodsIn [GET] [PUT] [POST] [ALL] [NONE]";
  return NULL;
}
/*
  CharsetRecodeMethodsOut GET PUT POST ALL NONE
 */
CMDCONST char *
add_charset_methods_out(cmd_parms *cmd,charset_dir_t *dc, char *method)
{
  if(!strcasecmp(method,"get"))
    dc->process_out |= PROCESS_GET;
  else if (!strcasecmp(method,"POST"))
    dc->process_out |= PROCESS_POST;
  else if (!strcasecmp(method,"PUT"))
    dc->process_out |= PROCESS_PUT;
  else if (!strcasecmp(method,"NONE"))
    dc->process_out = PROCESS_NONE;
  else if (!strcasecmp(method,"ALL"))
    dc->process_out = PROCESS_ALL;
  else 
    return "Usage: CharsetRecodeMethodsOut [GET] [PUT] [POST] [ALL] [NONE]";
  return NULL;
}

/*
  CharsetAutoRedirect charset http://server:port/dirprefix/
*/
CMDCONST char *
add_auto_redirect (cmd_parms *cmd, charset_dir_t *dc,char *cset, char *prefix)
{
  charset_redirect_t new_redirect;
  new_redirect.charset = cset;
  if(parse_urlprefix(prefix,cmd->pool,&new_redirect))
    {
      add_redirect_to_table(dc->auto_redirects,&new_redirect);
      return NULL;
    }
  else
    return "Cannot parse URL prefix, use http://server[:port]/dirprefix form";
}

CMDCONST char *
set_normalize_redirect (cmd_parms *cmd, charset_dir_t *dc, char *prefix,char *size)
{
  charset_redirect_t *new_redirect = ap_palloc(cmd->pool,sizeof(charset_redirect_t));

  if(parse_urlprefix(prefix,cmd->pool,new_redirect))
    {
      int s;
      if(size) 
	{
	  s = atoi(size);
	  if(s>0)
	    dc->redir_pic_minsize = s;
	  else
	    return "Cannot convert 3rd argument into positive integer";
	}
      dc->picture_url = new_redirect;
      return NULL;
    }
  else
    return "Cannot parse URL prefix, use http://server[:port]/dirprefix, :port, /dirprefix or none forms";
}

CMDCONST char *
set_types_redirect (cmd_parms *cmd, charset_dir_t *dc, char *type)
{
  processed_type_t *tp;
  tp=ap_push_array(dc->normalize_types);
  tp->typename=type;
  tp->len = strlen(type);
  return NULL;
}

/* CharsetRedirectFromOriginalURL on|off */
CMDCONST char *
set_use_unparseduri(cmd_parms *cmd, charset_dir_t *dc, int flag) 
{
  dc->use_unparseduri=flag?FL_ON:FL_OFF;
  return NULL;
}

/* CharsetNoAutoRedirectForDefaultCharset on|off */
CMDCONST char *
set_noredir_ag(cmd_parms *cmd, charset_dir_t *dc, int flag) 
{
  dc->no_redirect_defaults=flag?FL_ON:FL_OFF;
  return NULL;
}

/* ��� ������� */
command_rec charset_cmds[] = {
  { "CharsetDecl",add_charset_decl,NULL,RSRC_CONF,TAKE23,
    "charset name and language declaration"},
  { "CharsetRecodeTable",add_charset_recode_table,NULL,RSRC_CONF,RAW_ARGS,
    "recode table(s) declaration"},
  { "CharsetWideRecodeTable",add_wide_recode_table,NULL,RSRC_CONF,TAKE3,
    "charset_from charset_to wide_table_filename"},
  { "CharsetSelectionOrder",add_charset_selection_rules,NULL,OR_FILEINFO,RAW_ARGS,
    "charset selection order (Portnumber, Hostname, URIHostname, EnvVariable, Dirprefix, Useragent)"},
  { "CharsetSourceEnc",add_charset_source,NULL,OR_FILEINFO,TAKE1,
    "source (html,cgi,ssi) file charset"},
  { "CharsetByExtension",add_ext_charset,NULL,OR_FILEINFO,ITERATE2,
    "source charset by extension"},
  { "CharsetAlias", add_charset_alias,NULL,OR_FILEINFO, ITERATE2,
    "charset alias and charset name" },
  { "CharsetDefault", add_charset_default,NULL,OR_FILEINFO, TAKE1,
    "Name of default charset"},
  { "CharsetAgent", add_agent_charset,NULL,OR_FILEINFO, ITERATE2,
    "Set default charset for agent" },
  { "CharsetBadAgent", add_bad_agent,NULL,OR_FILEINFO, ITERATE,
    "Set agents, which can't understand charset in HTTP header" },
  { "CharsetErrReject", add_reject_error_charset,NULL,OR_FILEINFO, FLAG,
    "Set/unset rejecting error charset negotiation" },
  { "CharsetPriority", add_charset_priority,NULL,OR_FILEINFO, ITERATE,
    "Set charset priority" },
  { "CharsetMatchLanguage", add_charset_matchlang,(void*)1,OR_FILEINFO, FLAG,
    "force charset=... in content type only if charset language match document language" },
  { "CharsetUseMultiViews", add_charset_matchlang,NULL,OR_FILEINFO, FLAG,
    "force charset=... in content type only if charset language match document language" },
  { "CharsetRecodeHeaders", add_charset_recode_headers,NULL,OR_FILEINFO, FLAG,
    "Turn On recoding of ouput headers" },
  { "CharsetTurnOff", add_charset_turnoff,(void*)1,OR_FILEINFO, FLAG,
    "Outdated, use CharsetDisable" },
  { "CharsetDisable", add_charset_turnoff,NULL,OR_FILEINFO, FLAG,
    "Turn Off all charset-recognition code" },
  { "CharsetByPort", add_charset_byport,NULL,OR_FILEINFO, TAKE2,
    "Associate charset with TCP port" },
  { "CharsetRecodeFilenames",add_charset_recode_filenames,NULL,OR_FILEINFO,FLAG,
    "Turn On recoding of filenames"},
  /* support for soft redirection */
  { "CharsetSoftRedirect", charset_add_redirect, 
    (void*)HTTP_MOVED_TEMPORARILY, 
    OR_FILEINFO, TAKE23,
    "an optional status, then document to be redirected and destination URL" },
  { "CharsetSoftRedirectTemp", charset_add_redirect, 
    (void*)HTTP_MOVED_TEMPORARILY, 
    OR_FILEINFO, TAKE2,
    "a document to be redirected, then the destination URL" },
  { "CharsetSoftRedirectPermanent", charset_add_redirect, 
    (void*)HTTP_MOVED_PERMANENTLY, 
    OR_FILEINFO, TAKE2, 
    "a document to be redirected, then the destination URL" },
  { "CharsetProcessType", add_proctype, NULL,
    OR_FILEINFO, ITERATE, 
    "additional mime-type substring to be processed" },
  { "CharsetBrokenAccept", add_brokaccept, NULL,
    OR_FILEINFO, TAKE2, 
    "user-agent substring then full accept-charset string"},
  { "CharsetOverrideExpires",add_charset_override_expires,NULL,
    OR_FILEINFO,FLAG,
    "Turn On/Off override of Expires: header set by other modules"},
  { "CharsetStrictURIMatch",add_charset_stricturi,NULL,OR_FILEINFO,FLAG,
    "Turn On/Off strict hostname/directory match"},
  { "CharsetRecodeMethodsIn",add_charset_methods_in,NULL,OR_FILEINFO,ITERATE,
    "Methods to recode: GET|PUT|POST|ALL"},
  { "CharsetRecodeMethodsOut",add_charset_methods_out,NULL,OR_FILEINFO,ITERATE,
    "Methods to recode: GET|PUT|POST|ALL"},
  { "CharsetRecodeMultipartForms",add_charset_mpforms,NULL,OR_FILEINFO,FLAG,
    "Turn On/Off recoding of multipart/form-data datatype"},
  { "CharsetDisableForcedExpires",add_disable_expires,NULL,OR_FILEINFO,FLAG,
    "Turn On/Off forced Expires: header"},
  { "CharsetDisableAcceptCharset",add_disable_accept,NULL,OR_FILEINFO,FLAG,
    "Turn On/Off Accept-Charset recognition"},
  { "CharsetAutoRedirect",add_auto_redirect,NULL,OR_FILEINFO,TAKE2,
    "Specifies URL prefix for redirection of non-cacheable documents"},
  { "CharsetNormalizeToURL",set_normalize_redirect,NULL,OR_FILEINFO,TAKE12,
    "Specifies canonic URL prefix of images and other non-recoded files"},
  { "CharsetNormalizeTypes",set_types_redirect,NULL,OR_FILEINFO,ITERATE,
    "Specifies MIME types to normalize via CharsetNormalizeToURL"},
  { "CharsetRedirectFromOriginalURL",set_use_unparseduri,NULL,OR_FILEINFO,FLAG,
    "Use original (unparsed) URI as base for CharsetAutoRedirect"},
  { "CharsetNoAutoRedirectForDefaultCharset",set_noredir_ag,NULL,OR_FILEINFO,FLAG,
    "Do not autoredirect Use original (unparsed) URI as base for CharsetAutoRedirect"},
 { NULL }
};



/* =================== UTILS ================= */

#if 1

/* ������ � ��������� ������������� ��� ��������� �������� ������� */

static char*
read_table(FILE *fp, unsigned char *tab1, unsigned char *tab2)
{
  char string[MAX_STRING_LEN+1];
  unsigned int src,dst;
  int i;
  int bCharOK[TABLECHARS];
  
  for(i=0;i<TABLECHARS;i++) tab1[i]=i;
  if(tab2)
    for(i=0;i<TABLECHARS;i++)
    {
      tab2[i]   =i;
      bCharOK[i]=0;
    }


  while (fgets(string,MAX_STRING_LEN,fp) != NULL)
    {
      unsigned char *p,*strp;
      strp=string;
      while(*strp && isspace(*strp)) strp++;
      if(!*strp || *strp=='#') continue; /* empty line or comment */
      strp=strtok(strp," \t");
      p = strtok(NULL," \t\r\n#");
      if (strp[0]=='0' && strp[1]=='x')
	    sscanf(strp,"0x%x",&src);
      else
	    src=atoi(strp);
      if (p[0]=='0' && p[1]=='x')
	    sscanf(p,"0x%x",&dst);
      else
	    dst=atoi(p);

      if (src < 256 && dst <256)
      {
	    tab1[src]=dst?(unsigned char)dst:MOD_CHARSET_DEFAULT_CHAR;
        if (tab2)
        {
          if( bCharOK[dst] )
            return "Invalid recode table (non-uniqueness): Reverse table should be loaded explicitly";
          else
          {
            tab2[dst]=src?(unsigned char)src:MOD_CHARSET_DEFAULT_CHAR;
            bCharOK[dst] = 1;
          }
        }
      }
      else
	    return "Invalid recode table (values > 255)";
    }
  return NULL;
}

#else

static char*
read_table(FILE *fp, unsigned char *tab1, unsigned char *tab2)
{
  char string[MAX_STRING_LEN+1];
  unsigned int src,dst;
  int i;

  for(i=0;i<TABLECHARS;i++) tab1[i]=i;
  if(tab2) for(i=0;i<TABLECHARS;i++) tab2[i]=i;

  while (fgets(string,MAX_STRING_LEN,fp) != NULL)
    {
      unsigned char *p,*strp;
      strp=string;
      while(*strp && isspace(*strp)) strp++;
      if(!*strp || *strp=='#') continue; /* empty line or comment */
      strp=strtok(strp," \t");
      p = strtok(NULL," \t\r\n#");
      if (strp[0]=='0' && strp[1]=='x')
	sscanf(strp,"0x%x",&src);
      else
	src=atoi(strp);
      if (p[0]=='0' && p[1]=='x')
	sscanf(p,"0x%x",&dst);
      else
	dst=atoi(p);
      if (src < 256 && dst <256)
	{
	  tab1[src]=dst?(unsigned char)dst:MOD_CHARSET_DEFAULT_CHAR;
      if (tab2)
	    tab2[dst]=src?(unsigned char)src:MOD_CHARSET_DEFAULT_CHAR;
    }
      else
	return "Invalid recode table (values > 255)";
    }
  return NULL;
}

#endif

/*
  Case-insensitive strstr()
*/

static char *
strcasestr( const char *string, const char *pattern)
{
  const char *s, *p;
  char pchar;
  if( !(pchar = tolower( *pattern )) ) 
    return NULL;

  for( ; *string; string++)
    if( tolower( *string ) == pchar )
      for( s = string+1, p = pattern+1; ; s++, p++)
	{
	  if( !*p ) 
	    return (char *) string;
	  if( !*s ) 
	    return NULL;
        if( tolower( *p ) != tolower( *s ) ) break;
	}
  return NULL;
  
}



static void 
add_redirect_to_table(array_header *h, charset_redirect_t *rd) 
{
  int i;
  charset_redirect_t *t = (charset_redirect_t *) h->elts;
  if(!rd) return;
  if(rd->charset) 
    {
      for(i=0;i<h->nelts;i++)
	{
	  if(!strcasecmp(t[i].charset,rd->charset))
	    {
	      t[i].server=rd->server;
	      t[i].port = rd->port;
	      t[i].prefix=rd->prefix;
	      return;
	    }
	}
    }
  t = ap_push_array(h);
  t->charset = rd->charset;
  t->server  = rd->server;
  t->port    = rd->port;
  t->prefix  = rd->prefix;
}

static array_header *
merge_redirect_tables(ap_pool *p, array_header *base, array_header *override) 
{
  int i;
  array_header *ret = ap_copy_array(p,base);
  charset_redirect_t *rd = (charset_redirect_t *) override->elts;
  for (i=0; i< override->nelts; i++)
	 add_redirect_to_table(ret,rd+i);
  return ret;
}

static int
parse_urlprefix (char *prefix, ap_pool *p, charset_redirect_t *redir)
{
  char *serverp,*urlp,*portp,*slashp;

  redir->server = NULL;
  redir->port = 0;
  redir->prefix = NULL;

  if(!prefix)
      return 0;

  if(!strcasecmp(prefix,"none"))
    return 1;

  if(*prefix == ':')
    {
      /* only port */
      redir->port = atoi(prefix+1);
      return redir->port ? 1: 0;
    }
  else if(!strncasecmp("http://",prefix,7))
     {
       /* we've server specified in prefix */
       serverp = prefix+7;
       urlp = strchr(serverp,'/');
       if (urlp)
	 {
	   *urlp='\0'; 
	   urlp++;
	   if(strlen(urlp)>1) 
	     {
	       slashp = strrchr(urlp,'/');
	       if ((strlen(urlp)>0) && (!slashp || ((slashp-urlp+1) < strlen(urlp)))) 
		 /* no trailing slash */
		 redir->prefix=ap_pstrcat(p,"/",urlp,"/",NULL);
	       else
		 redir->prefix=ap_pstrcat(p,"/",urlp,NULL);
	     }
	 } /* urlp */

       portp = strchr(serverp,':');
       if (portp) 
	 {
	   *portp = '\0'; /*split serverp into server and port path */
	   portp++;
	   redir->port = atoi(portp);
	   redir->server = ap_pstrdup(p,serverp);
	 } 
       else /* portp */
	 {
	   redir->server = ap_pstrdup(p,serverp);
	   redir->port = 0; /* we'll preserve port across redirects */
	 }
     } 
  else /* not http:// */
    {
      /* no server/port path */

      if(*prefix != '/')
	return 0;

      slashp = strchr(prefix+1,'/');
      if (!slashp && strlen(prefix)>1)
	{
	  redir->prefix=ap_pstrcat(p,prefix,"/",NULL);
	}
      else
	{
	  redir->prefix = ap_pstrdup(p,prefix);
	}
    } /* end if ... http:// */
  return 1;
}


static void
split_uri(request_rec *r, charset_dir_t *dc, char ** auser, char **aurl)
{
  char *uri,*userp;
  char *orig;
  if(dc->use_unparseduri !=FL_ON)
      orig = r->uri;
  else
    {
      orig = ap_pstrdup(r->pool,r->unparsed_uri);
      ap_unescape_url(orig);
    }

  if(orig[0]=='/'  && orig[1] == '~')
    {
      uri = strchr(orig+1,'/');
      if(!uri)
	uri = orig+strlen(r->uri);
      userp=ap_pstrndup(r->pool,orig,uri-orig);
    }
  else
    {
      userp=NULL;
      uri = orig;
    }
  *auser = userp;
  *aurl = uri;
}

static int
check_for_canonic(request_rec *r,charset_dir_t *dc,charset_redirect_t *redir, 
		  int check_server, int check_port,  int check_prefix)
{
  int server_match=0,port_match=0,prefix_match=0;
  const char *host;
  char *uri,*userp;
  int port;

  if(!redir) return 1;
  if(!r || !r->uri) return 1;
  if(!redir->server && !redir->port && !redir->prefix) 
    return 1;

  host = (r->main && r->main->hostname) ? r->main->hostname 
    : r->hostname 
    ?r->hostname:r->server->server_hostname;
  port = r->connection?htons(r->connection->local_addr.sin_port):0;

  if(check_server && redir->server)
    {
      if( (r->server && !strcasecmp(r->server->server_hostname,redir->server)) 
	  || (host && !strcasecmp(host,redir->server)) )
	server_match = 1;
      else
	server_match = 0;
    }
  else
    server_match = 1;
  
  if(check_port && redir->port)
    port_match = (redir->port == port);
  else
    port_match = 1;


  if(check_prefix && redir->prefix)
      {
	  split_uri(r,dc,&userp,&uri);
	  if(uri[strlen(uri)] == '/')
	      {
		  /* directory prefix terminated with slash */
		  prefix_match=!strncmp(uri,redir->prefix,strlen(redir->prefix));
	      }
	  else 
	      {
		  /* directory without trailing slash */
		  prefix_match=!strncmp(uri,redir->prefix,strlen(redir->prefix)-1);
	      }
      }
  else
      prefix_match = 1;

  return server_match && port_match && prefix_match;
}




static const char *
rewrite_url (request_rec *r,charset_dir_t* dc,charset_redirect_t *redir)
{
  int i,len;
  int nrds = dc->auto_redirects->nelts;
  int premoved = 0;
  charset_redirect_t *rds = (charset_redirect_t*) dc->auto_redirects->elts;
  char *ret;
  
  char *userp, *url,*nurl;

  if(!redir || !r || !r->uri) return NULL; /* no rewrite */
  if(!redir->server && !redir->port && !redir->prefix)
    return NULL;

  split_uri(r,dc,&userp,&url);

  for(i=0;i<nrds;i++)
    {
      if(rds[i].prefix && !strncmp(url,rds[i].prefix,len=strlen(rds[i].prefix)))
	{
	  url+=len; /* remove entire prefix */
	  premoved = 1;
	  break;
	}
    }

  if(!premoved && *url == '/') /* original url begins with slash, remove it because */
    url++;			/* we'll insert slash anyway */

  nurl = ap_pstrcat(r->pool,userp?userp:"",redir->prefix?redir->prefix:"/",url,NULL);

  if(dc->use_unparseduri != FL_ON)
    ret = ap_pstrcat(r->pool,ap_http_method(r),"://",
		     ap_construct_server(r->pool, 
					 redir->server ? redir->server 
					 :(r->main && r->main->hostname) ? r->main->hostname
					 : r->hostname ? r->hostname : r->server->server_hostname,
					 redir->port?redir->port
					 :htons(r->connection->local_addr.sin_port),
					 r),
		     ap_escape_uri(r->pool,nurl),
		     r->args?"?":"",r->args?r->args:"",
		     r->parsed_uri.fragment?"#":"",r->parsed_uri.fragment,
		     NULL);
  else /* unparseduri: args part is already in URL */
    ret = ap_pstrcat(r->pool,ap_http_method(r),"://",
		     ap_construct_server(r->pool, 
					 redir->server ? redir->server 
					 :(r->main && r->main->hostname) ? r->main->hostname
					 : r->hostname ? r->hostname : r->server->server_hostname,
					 redir->port?redir->port
					 :htons(r->connection->local_addr.sin_port),
					 r),
		     ap_escape_uri(r->pool,nurl),NULL);
  /* end unparseduri */
  return ret;

}

static int 
already_rewrited(request_rec *r,charset_dir_t *dc,charset_redirect_t *redir)
{
  if(!redir) return 1;
  if(!redir->server && !redir->port && !redir->prefix) return 1;
  if(!r || !r->uri) return 1;
  return check_for_canonic(r,dc,redir,1,1,1);
}

static int 
image_is_rewrited(request_rec *r, charset_dir_t *dc,charset_redirect_t *redir)
{
  int url_ok = 0;
  int nrds,i;
  char *userp, *url;
  charset_redirect_t *rds;

  if(!redir) return 1;
  if(!redir->server && !redir->port && !redir->prefix) return 1;
  if(!r || !r->uri) return 1;
  if (check_for_canonic(r,dc,redir,1,1,0))
    url_ok = 1;
  else
    return 0;

  split_uri(r,dc,&userp,&url);
  nrds = dc->auto_redirects->nelts;
  rds = (charset_redirect_t*) dc->auto_redirects->elts;
  for(i=0;i<nrds;i++)
    {
      if(rds[i].prefix && !strncmp(url,rds[i].prefix,strlen(rds[i].prefix)))
	{
	  url_ok = 0; /* we've rewrite something */
	  break;
	}
    }
  return url_ok;
}

static int 
bad_agent_accept(charset_dir_t *dc, const char *agent, const char *accept)
{
  int i;
  broken_accept_t *bp = (broken_accept_t *)dc->broken_accepts->elts;
  if(!agent || !accept)
    return 0;
  for (i = 0; i < dc->broken_accepts->nelts;i++) {
    if(!strcasecmp(accept,bp[i].accept_string) 
       && strcasestr(agent,bp[i].agent_substring))
      return 1;
  }
  return 0;
}

/* get 1st table entry with key first chars of bkey */
static char *
strncmp_table_get(table *tt, const char *bkey,int strict,char *delim)
{
  array_header *t = (array_header*)tt;
  table_entry *elts = (table_entry *)t->elts;
  int i,len;
  
  if (bkey == NULL) return NULL;
  for (i = 0; i < t->nelts; ++i)
    {
      len = strlen(elts[i].key);
      if (!strncasecmp (bkey,elts[i].key, len))
	if(!strict || bkey[len] == '\0' ||  strchr(delim,bkey[len]))
	  return elts[i].val;
    }
  return NULL;
}

/* get 1st table entry with key, which substring of bkey */
static char *
strstr_table_get(table *tt, const char *bkey)
{
  array_header *t = (array_header*)tt;
  table_entry *elts = (table_entry *)t->elts;
  int i;
  
  if (bkey == NULL) return NULL;
  for (i = 0; i < t->nelts; ++i)
    if (strcasestr (bkey,elts[i].key))
      return elts[i].val;
  return NULL;
}

static charset_table_t *
strncmp_getcharset(charset_dir_t *dirconf,const char *bstr, int strict,
		   char *delim)
{
  const char *cname;
  if(bstr == NULL) return NULL;
  cname= strncmp_table_get(dirconf->charset_aliases,bstr,strict,delim);
  if(cname)
    return get_chtable(dirconf,cname);
  else
    return strncmp_get_chtable(dirconf,bstr,strict,delim);
}

static charset_table_t *
exact_getcharset(charset_dir_t *dirconf,const char *bstr)
{
  const char *cname = ap_table_get(dirconf->charset_aliases,bstr);
  if(cname)
    return get_chtable(dirconf,cname);
  else
    return get_chtable(dirconf,bstr);
}


/********       *******
 * Recoding functions *
 *******        *******/


static int 
is2hd(const unsigned char *c)
{
  return isxdigit(*c) && isxdigit(*(c+1));
}

static unsigned int
get2hd (const unsigned char *s)
{
  char buf[3];
  unsigned int ret;
  buf[0]=s[0]; buf[1]=s[1];buf[2]='\0';
  sscanf(buf,"%02x",&ret);
  return ret;
}


static void 
check_recode_buf(ap_pool *p,local_buf_t *buf, const unsigned int len) 
{
  if(len > buf->len) 
    {
      buf->buf=ap_palloc(p,buf->len = RECODE_ALLOC_CHUNK*(len/RECODE_ALLOC_CHUNK+2));
    }
}


API_EXPORT(int) 
ra_calc_wide_len (const unsigned char *buf, const int len,
	       wide_table_t *tbl)
{
  int nlen=0,i;
  for (i=0;i<len;i++)
    if(tbl->len[buf[i]]>0)
      nlen += tbl->len[buf[i]];
    else
      nlen++;
  return nlen;
}


/*
 * Converts string buf to *result by using table recode_table
 * %AA-escapes are not converted
 *
 * returns NULL/0 on error
 *
 */


API_EXPORT(void)
ra_in_place_convert_by_table( unsigned char *buf, const unsigned int len,
			     const unsigned char *recode_table)
{
  int i;
  if(!buf || !len)
    return;

  if(recode_table)
      for(i=0;i<len;i++)
	buf[i]=recode_table[buf[i]];
}
	  

API_EXPORT(void)
ra_convert_by_table(const  unsigned char *buf, const unsigned int len,
			    unsigned char ** result, unsigned int* rlen,
			    const unsigned char *recode_table, int wide,
			    ap_pool *p, local_buf_t *localdata)
{
  unsigned int i,j;
  unsigned char *ret;
  
  if(!localdata || !p || !buf ||!len)
    {
      *result = NULL;
      *rlen = 0;
      return; 
    }

  if(!recode_table)
    {
      check_recode_buf(p,localdata,len);
      memcpy(localdata->buf,buf,len);
      *result = localdata->buf;
      *rlen = len;
      return;
    }

  if(!wide)
    {
      check_recode_buf(p,localdata,len);
      ret = localdata->buf;
      for(i=0;i<len;i++)
	ret[i] = recode_table[buf[i]];
      *result = ret;
      *rlen   = len;
      return;
    }
  else
    {
      unsigned int nlen;
      unsigned char *pt;
      wide_table_t *wt = (wide_table_t*)recode_table;
      nlen=ra_calc_wide_len(buf,len,wt);
      check_recode_buf(p,localdata,nlen);
      pt = localdata->buf;
      for(i=0;i<len;i++)
	if(wt->len[buf[i]]>0)
	  for(j=0;j<wt->len[buf[i]];j++)
	    *pt++ = wt->table[wt->offsets[buf[i]]+j];
	else
	  *pt++=buf[i];
      *result = localdata->buf;
      *rlen = nlen;
    }
}


API_EXPORT(void)
ra_in_place_convert_by_table_esc(unsigned char *buf, const unsigned int len,
				const unsigned char *recode_table)
{
  if(!buf ||!len)
    return;

  if(recode_table)
    {
      unsigned char tbuf[4];
      unsigned char *src = buf;
      unsigned char *dest;
      unsigned int i,j;

      dest = buf;
      
      for(i=0;i<len;)
	{
	  if((i<len-2) && src[i]=='%' && is2hd(src+i+1))
	    {
	      unsigned char z = get2hd(src+i+1);
	      ap_snprintf(tbuf,4,"%%%02X",(unsigned int) recode_table[z]);
	      for (j=0;j<3;j++)
		dest[i+j] = tbuf[j];
	      i+=3;
	    }
	  else
	    {
	      dest[i] = recode_table[src[i]];
	      i++;
	    }
	}
    }
} 




  
API_EXPORT(void)
ra_convert_by_table_esc(const unsigned char *buf, const unsigned int len,
			unsigned char ** result, unsigned int* rlen,
			const unsigned char *recode_table, int wide,
			ap_pool *p, local_buf_t *localdata)
{

  if(!localdata || !p || !buf ||!len)
    {
      *result = NULL;
      *rlen = 0;
      return; 
    }

  if(!recode_table)
    {
      check_recode_buf(p,localdata,len);
      memcpy(localdata->buf,buf,len);
      *result = localdata->buf;
      *rlen = len;
      return;
    }

  if(!wide)
    {
      unsigned char tbuf[4];
      unsigned char *dest;
      unsigned int i,j;

      check_recode_buf(p,localdata,len);
      *result = dest = localdata->buf;
      
      for(i=0;i<len;)
	{
	  if(buf[i]=='%' && is2hd(buf+i+1))
	    {
	      unsigned char z = get2hd(buf+i+1);
	      ap_snprintf(tbuf,4,"%%%02X",(unsigned int) recode_table[z]);
	      for (j=0;j<3;j++)
		dest[i+j] = tbuf[j];
	      i+=3;
	    }
	  else
	    {
	      dest[i] = recode_table[buf[i]];
	      i++;
	    }
	}
      *rlen = len;
      return;
    } /* if (!wide ) */
  else
    {
      /*  wide characters possible */
      unsigned char *wide_buff, *pct_buff;
      unsigned char *dst;
      ap_pool *tpool;
      int  decoded_len = 0, return_len=0, chr_len;
      int  i,j;
      wide_table_t *wt = (wide_table_t *) recode_table;

      tpool = ap_make_sub_pool(p);
      wide_buff=ap_palloc(tpool,len);
      pct_buff =ap_palloc(tpool,len);

      for(i=0;i<len;)
	{
	  if(buf[i]=='%' && is2hd(buf+i+1))
	    {
	      wide_buff[decoded_len] = get2hd(buf+i+1);
	      pct_buff[decoded_len] = 1;
	      i+=3;
	    }
	  else
	    {
	      wide_buff[decoded_len] = buf[i];
	      pct_buff[decoded_len] = 0;
	      i++;
	    }
	  decoded_len++;
	}


      /* calculate new header length */
      for(i=0;i<decoded_len;i++)
	{
	  chr_len = wt->len[wide_buff[i]];
	  if(chr_len == 0) chr_len = 1;
	  if(pct_buff[i]) chr_len*=3;
	  return_len+=chr_len;
	}
      check_recode_buf(p,localdata,return_len);
      *result = localdata->buf;
      dst = localdata->buf;
      *rlen = return_len;

      for (i=0;i<decoded_len;i++)
	{
	  if(pct_buff[i])
	    {
	      if(wt->len[wide_buff[i]]>0)
		for(j=0;j<wt->len[wide_buff[i]];j++)
		  {
		    ap_snprintf(dst,4,"%%%02X",
				(unsigned int)wt->table[wt->offsets[wide_buff[i]]+j]);
		    dst+=3;
		  }
	      else
		{
		  ap_snprintf(dst,4,"%%%02X",(unsigned int)wide_buff[i]);
		  dst+=3;
		}
	    }
	  else
	    {
	      if(wt->len[wide_buff[i]])
		for(j=0;j<wt->len[wide_buff[i]];j++)
		  *dst++=wt->table[wt->offsets[wide_buff[i]]+j];
	      else
		*dst++=wide_buff[i];
	    }
	}
      ap_destroy_pool(tpool);
    }
} 


API_EXPORT(void) ra_data_server2client(request_rec *r, 
				       const unsigned char *buf,const unsigned int len,
				       unsigned char **new_buf, unsigned int *new_len)
{
  int wide=0;
  if(buf && len && ra_charset_ok(r)) {
      if(ra_flag(r,RA_WIDE_CHARS_SC)) wide=1;
      ra_convert_by_table( buf,len,new_buf,new_len, r->ra_codep->cp_otabl_p,wide,
			   r->pool,r->ra_codep->recode_buffer_out);
  } else{
      *new_buf=NULL;
      *new_len=0;
  }
}

API_EXPORT(void) 
ra_data_server2client_esc(request_rec *r, const unsigned char *buf,const unsigned int len,
			  unsigned char **new_buf, unsigned int *new_len)
{
  int wide=0;
  if(buf && len && ra_charset_ok(r)) {
      if(ra_flag(r,RA_WIDE_CHARS_SC)) wide=1;
      ra_convert_by_table_esc( buf,len,new_buf,new_len, r->ra_codep->cp_otabl_p,wide,
			       r->pool,r->ra_codep->recode_buffer_out);
  }else{
    *new_buf=NULL;
    *new_len=0;
  }
}

API_EXPORT(unsigned char *) 
ra_str_server2client(request_rec *r, const unsigned char *buf)
{
  int wide=0;
  if(buf && ra_charset_ok(r)) {
      unsigned int len = strlen(buf)+1;
      unsigned char *newbuf;
      unsigned int nlen;
      if(ra_flag(r,RA_WIDE_CHARS_SC))wide=1;
      ra_convert_by_table( buf,len,&newbuf,&nlen, r->ra_codep->cp_otabl_p,wide,
			   r->pool,r->ra_codep->recode_buffer_out);
      newbuf[nlen]='\0';
      return newbuf;
  } else
    return NULL;
}

API_EXPORT(unsigned char *) 
ra_str_server2client_esc(request_rec *r, const unsigned char *buf)
{
  int wide=0;
  if(buf && ra_charset_ok(r)) {
      unsigned int len = strlen(buf)+1;
      unsigned char *newbuf;
      unsigned int nlen;
      if(ra_flag(r,RA_WIDE_CHARS_SC))wide=1;
      ra_convert_by_table_esc( buf,len,&newbuf,&nlen, r->ra_codep->cp_otabl_p,wide,
			       r->pool,r->ra_codep->recode_buffer_out);
      newbuf[nlen]='\0';
      return newbuf;
  } else
    return NULL;
}


API_EXPORT(void) ra_data_client2server(request_rec *r, 
				       const unsigned char *buf,const unsigned int len,
				       unsigned char **new_buf, unsigned int *new_len)
{
  if(buf && len && ra_charset_ok(r)) {
      ra_convert_by_table( buf,len,new_buf,new_len, r->ra_codep->cp_itabl_p,0,
			   r->pool,r->ra_codep->recode_buffer_in);
  } else{
      *new_buf=NULL;
      *new_len=0;
  }
}

API_EXPORT(void) 
ra_data_client2server_esc(request_rec *r, const unsigned char *buf,const unsigned int len,
			  unsigned char **new_buf, unsigned int *new_len)
{
  if(buf && len && ra_charset_ok(r)) {
      ra_convert_by_table_esc( buf,len,new_buf,new_len, r->ra_codep->cp_itabl_p,0,
			       r->pool,r->ra_codep->recode_buffer_in);
  }else{
    *new_buf=NULL;
    *new_len=0;
  }
}

API_EXPORT(unsigned char *) 
ra_str_client2server(request_rec *r, const unsigned char *buf)
{
  if(buf && ra_charset_ok(r)) {
      unsigned int len = strlen(buf)+1;
      unsigned char *newbuf;
      unsigned int nlen;
      ra_convert_by_table( buf,len,&newbuf,&nlen, r->ra_codep->cp_itabl_p,0,
			   r->pool,r->ra_codep->recode_buffer_in);
      newbuf[nlen]='\0';
      return newbuf;
  } else
    return NULL;
}

API_EXPORT(unsigned char *) 
ra_str_client2server_esc(request_rec *r, const unsigned char *buf)
{
  if(buf && ra_charset_ok(r)) {
      unsigned int len = strlen(buf)+1;
      unsigned char *newbuf;
      unsigned int nlen;
      ra_convert_by_table_esc( buf,len,&newbuf,&nlen, r->ra_codep->cp_itabl_p,0,
			       r->pool,r->ra_codep->recode_buffer_out);
      newbuf[nlen]='\0';
      return newbuf;
  } else
    return NULL;
}




API_EXPORT(int)
ra_charset_ok(request_rec *r)
{
  if(r && r->ra_codep && r->ra_codep->cp_name && r->ra_codep->cp_fromname)
    return 1;
  else
    return 0;
}


API_EXPORT(int)
ra_no_of_charsets(request_rec *r)
{
  charset_dir_t   *dirconf; 
  array_header *t;
  if(!ra_charset_ok(r))
    return 0;
  dirconf = ap_get_module_config(r->per_dir_config, &charset_module);
  t = dirconf->charset_tables;
  return t->nelts;

}     
  
API_EXPORT(char *)
ra_charset_name(request_rec *r, int no)
{
  charset_dir_t   *dirconf; 
  array_header *t;
  charset_table_t *p;

  if(!ra_charset_ok(r))
    return NULL;
  dirconf = ap_get_module_config(r->per_dir_config, &charset_module);
  t = dirconf->charset_tables;
  p = (charset_table_t*)t->elts;
  if(no >=0 && no < t->nelts)
    return p[no].tablename;
  else
    return NULL;
}

API_EXPORT(int)
ra_charset_index(request_rec *r, const char *name)
{
  charset_dir_t   *dirconf; 
  array_header *t;
  charset_table_t *p;
  int i;

  if(!ra_charset_ok(r))
    return -1;

  dirconf = ap_get_module_config(r->per_dir_config, &charset_module);
  t = dirconf->charset_tables;
  p = (charset_table_t*)t->elts;
  for(i=0;i<t->nelts;i++)
    if(!strcasecmp(p[i].tablename,name))
      return i;
  return -1;

}

API_EXPORT(char *)
ra_client_charset(request_rec *r)
{
  if(!ra_charset_ok(r))
    return NULL;
  return r->ra_codep->cp_name;
}

API_EXPORT(char *)
ra_server_charset(request_rec *r)
{
  if(!ra_charset_ok(r))
    return NULL;
  return r->ra_codep->cp_fromname;
}

static recode_table_t *
recode_table_by_names(request_rec *r, const char *from, const char *to)
{
  charset_dir_t   *dirconf; 
  charset_table_t *t;
  if(!ra_charset_ok(r))
    return NULL;
  dirconf = ap_get_module_config(r->per_dir_config, &charset_module);
  if(!from || !to)
    return NULL;
  t = get_chtable(dirconf,to);
  if(!t) return NULL;
  return find_recode_table(t->recode_tables,from);
}

#define wrong_params (!r || !p || !from || !to || !data|| !(rt=recode_table_by_names(r,from,to)))


API_EXPORT(void)
ra_recode_data(request_rec *r,ap_pool *p,const char *from, const char *to,
	       const void *data, const unsigned len,void **result, unsigned *rlen)
{
  recode_table_t *rt;
  local_buf_t *buf;
  if(wrong_params)
    {
      *result = NULL;
      *rlen = 0;
      return;
    }

  buf = ap_pcalloc(p,sizeof(local_buf_t));
  ra_convert_by_table((const unsigned char*)data,len,(unsigned char **)result,rlen,
		      rt->convtbl_ptr,rt->flags&RA_WIDE_CHARS_SC,p,buf);
}

API_EXPORT(void)
ra_recode_data_esc(request_rec *r,ap_pool *p,const char *from, const char *to,
	       const void *data, const unsigned len,void **result, unsigned *rlen)
{
  recode_table_t *rt;
  local_buf_t *buf;
  if(wrong_params)
    {
      *result = NULL;
      *rlen = 0;
      return;
    }
  buf = ap_pcalloc(p,sizeof(local_buf_t));
  ra_convert_by_table_esc((const unsigned char*) data,len,(unsigned char **)result,rlen,
			  rt->convtbl_ptr,rt->flags&RA_WIDE_CHARS_SC,p,buf);
}

API_EXPORT(char *)
ra_recode_str(request_rec *r,ap_pool *p,const char *from, const char *to,const char *data)
{
  recode_table_t *rt;
  local_buf_t *buf;
  int len,rlen;
  unsigned char *ret;

  if(wrong_params)
      return NULL;
  len = strlen(data)+1;
  buf = ap_pcalloc(p,sizeof(local_buf_t));
  ra_convert_by_table(data,len,&ret,&rlen,rt->convtbl_ptr,rt->flags&RA_WIDE_CHARS_SC,p,buf);
  return ret;
}

API_EXPORT(char *)
ra_recode_str_esc(request_rec *r,ap_pool *p,const char *from, const char *to,const char *data)
{
  recode_table_t *rt;
  local_buf_t *buf;
  int len,rlen;
  unsigned char *ret;
  if(wrong_params)
    return NULL;
  len = strlen(data)+1;
  buf = ap_pcalloc(p,sizeof(local_buf_t));
  ra_convert_by_table_esc(data,len,&ret,&rlen,rt->convtbl_ptr,rt->flags&RA_WIDE_CHARS_SC,p,buf);
  return ret;
}


#ifndef OLD_BREAD
/*
  From ap_bread comment:
 * Read up to nbyte bytes into buf.
 * If fewer than byte bytes are currently available, then return those.
 * Returns 0 for EOF, -1 for error.
 */
#define min(a,b) (((a)>(b))?(b):(a))

API_EXPORT(int)
charset_bread(BUFF *fb, void *vbuf, int nbyte,codepage_data_t* ra_codep)
{
  unsigned char *zbuf = (unsigned char *)vbuf;
  unsigned char *tab;
  int len_to_read=nbyte;
  int len_to_return = 0;
  int recode_offset = 0;
  int i,l,len_read, readahead_len,buffered_len;

  if(!ra_codep || !ra_codep->cp_itabl_p)
    return ap_bread(fb,zbuf,nbyte);
  tab=ra_codep->cp_itabl_p;


  /* ����������� postbuf � zbuf. ����������� ������� postbuf
     � ��� ������. postbuf ��� �������������! */
  l = min(nbyte,ra_codep->post_len);
  if(l>0)
    {
      memmove(zbuf,ra_codep->post_buf,l);
      memmove(ra_codep->post_buf,ra_codep->post_buf+l,ra_codep->post_len-l);
      ra_codep->post_len-=l;
      len_to_read -=l;
      len_to_return+=l;
      recode_offset = l;
    }
 error_return:
  /* ���� �� �������� ��� ������ ��� EOF, �� ������ ���-�� ������
     ��� ������  */
  if(ra_codep->post_err || ra_codep->post_eof)
    {
      /* ���� zbuf ���� - ������ ��� ������ ��� EOF */
      if(len_to_return == 0)
	return ra_codep->post_eof?0:ra_codep->post_errcode;
      else
	/* ����� ������ zbuf, � ������ ������ � ������ ���*/
	return len_to_return;
    }

  /* ���� ��� ������ ��� ���� � zbuf - ��������� ������ */
  if(len_to_return == nbyte)
    return len_to_return;

  /* ��������� ������� ���� � ����� */
  len_read =  ap_bread(fb,zbuf+len_to_return,
		       min(ra_codep->bytes_remaining,nbyte-len_to_return));
  /* ������ ������ - ������ �� ����������� */
  if(len_read <= 0)
    {
      ra_codep->bytes_remaining = 0;
      if(!len_read)
	ra_codep->post_eof = 1;
      else
	{
	  ra_codep->post_err = 1;
	  ra_codep->post_errcode = len_read;
	}
      goto error_return;
    }
  len_to_return+=len_read;
  ra_codep->bytes_remaining -=len_read;
  /* ���� ��������� ��� ������������� ����������� ���� - % -
     ����������� ��� � postbuf (�� � ����� ������� ������ ����
     ����) */
  if(zbuf[len_to_return-1] == '%')
    {
      readahead_len = 2;
      buffered_len = 1;
      ra_codep->post_buf[0] = zbuf[len_to_return-1];
    }
  else if(len_read>1 && zbuf[len_to_return-2]=='%')
    {
      readahead_len = 1;
      buffered_len = 2;
      ra_codep->post_buf[0] = zbuf[len_to_return-2];
      ra_codep->post_buf[1] = zbuf[len_to_return-1];
    }
  else
    {
      readahead_len = 0;
      buffered_len = 0;
    }
  /* ������������ zbuf, �� ����������� ������ � ������ */
  ra_in_place_convert_by_table_esc(zbuf+recode_offset, len_read-buffered_len ,tab);

  if(readahead_len>0 && buffered_len>0 && ra_codep->bytes_remaining > 0)
    {
      int post_offset = 3-readahead_len;
      /* �������� ������� ���� (1-2 �����) */
      len_read =
	ap_bread(fb,ra_codep->post_buf+post_offset,
		 min(ra_codep->bytes_remaining,readahead_len));
      if(len_read > 0)
	{
	  ra_codep->bytes_remaining-=len_read;
	  if(len_read < readahead_len && ra_codep->bytes_remaining > 0) /* ���������� */
	    {
	      /* ������-��, ��� ������� �� ����� ���� ������ ������ :) */
	      int len_read2;
	      len_read2 = ap_bread(fb,ra_codep->post_buf+post_offset+
				   len_read,
				   min(ra_codep->bytes_remaining,readahead_len-len_read));
	      if(len_read2 > 0)
		{
		  len_read+= len_read2;
		  ra_codep->bytes_remaining -= len_read2;
		}
	      else if(len_read2 == 0)
		ra_codep->post_eof = 1;
	      else 
		{
		  ra_codep->post_err = 1;
		  ra_codep->post_errcode = len_read2;
		}
	    }
	  /* ���� ���� ����������� ������ ��� readahead_len,
	     ������� �� ��� ������ �� ����� - ������ ������
	     �� �����  - �� ����������� ����������*/
	  ra_in_place_convert_by_table_esc(ra_codep->post_buf, 
					   len_read+buffered_len, tab);
	}
      else if(len_read==0)
	ra_codep->post_eof = 1;
      else
	{
	  ra_codep->post_err = 1;
	  ra_codep->post_errcode = len_read;
	}
      /* ������ buffered_len � zbuf */
      for(i=0;i<buffered_len;i++)
	zbuf[len_to_return-buffered_len+i] = ra_codep->post_buf[i];
      /* �������� post_buf */
      if(len_read>0)
	{
	  for(i=0;i<len_read;i++)
	    ra_codep->post_buf[i] =
	      ra_codep->post_buf[i+buffered_len];
	  ra_codep->post_len = len_read;
	}
      else
	ra_codep->post_len = 0;
    }
  /* ������� vbuf ���� ��� ��� ��� ������*/
  return len_to_return;
}
    
#else

#define min(a,b) (((a)>(b))?(b):(a))

API_EXPORT(int)
charset_bread(BUFF *fb, void *vbuf, int nbyte,codepage_data_t* ra_codep)
{
  int b_len,len=0;
  unsigned char *tab;
  unsigned char *zbuf = (unsigned char *) vbuf;

  if(!ra_codep || !ra_codep->cp_itabl_p)
    return ap_bread(fb,zbuf,nbyte);
  tab=ra_codep->cp_itabl_p;

  /* have pending error */
 pending_error:
  if(ra_codep->errflag)
    {
      int b = min(nbyte,ra_codep->postlen);
      if(ra_codep->postlen==0)
	return ra_codep->errcode;
      memcpy(zbuf,ra_codep->postbuf,b);
      memmove(ra_codep->postbuf,ra_codep->postbuf+b,ra_codep->postlen-b);
      ra_codep->postlen-=b;
      return b;
    }
  if(nbyte > ra_codep->postlen)
    b_len = ap_bread(fb,zbuf+ra_codep->postlen,nbyte-ra_codep->postlen);
  else
    b_len = 0;
  if(b_len <= 0)
    {
      ra_codep->errflag = 1;
      ra_codep->errcode = b_len;
      goto pending_error;
    }
  memcpy(zbuf,ra_codep->postbuf,ra_codep->postlen);
  len = b_len+ra_codep->postlen;

  /* save chars for later processing */
  if(zbuf[len-2] == '%')
    {
      ra_codep->postbuf[0] = zbuf[len-2];
      ra_codep->postbuf[1] = zbuf[len-1];
      ra_in_place_convert_by_table_esc(zbuf+ra_codep->postlen,b_len-2,tab);
      b_len = ap_bread(fb,&ra_codep->postbuf[2],1);
      if (b_len <= 0)
        {
          ra_codep->errflag = 1;
          ra_codep->errcode = b_len;
          ra_codep->postlen = 0;
        }
      else
        {
          ra_in_place_convert_by_table_esc(ra_codep->postbuf,3,tab);
          zbuf[len-2] = ra_codep->postbuf[0];
          zbuf[len-1] = ra_codep->postbuf[1];
          ra_codep->postbuf[0] = ra_codep->postbuf[2];
          ra_codep->postlen = 1;
	}
    }
  else if(zbuf[len-1]=='%')
    {
      ra_codep->postbuf[0]=zbuf[len-1];
      ra_in_place_convert_by_table_esc(zbuf+ra_codep->postlen,b_len-1,tab);
      b_len = ap_bread(fb,&ra_codep->postbuf[1],2);
      ra_codep->postlen = 1;
      if (b_len == 1)
        {
          ra_codep->postlen = 1;
        }
      else if (b_len <= 0)
        {
          ra_codep->errflag = 1;
          ra_codep->errcode = b_len;
          ra_codep->postlen = 0;
	}
      else
        {
          ra_in_place_convert_by_table_esc(ra_codep->postbuf,3,tab);
          zbuf[len-1] = ra_codep->postbuf[0];
          ra_codep->postbuf[0] = ra_codep->postbuf[1];
          ra_codep->postbuf[1] = ra_codep->postbuf[2];
          ra_codep->postlen = 2;
	}
    }
  else
    {
    ra_in_place_convert_by_table_esc(zbuf+ra_codep->postlen,b_len,tab);
    ra_codep->postlen = 0;
    }

  return len;
}  
#endif  

/* ================== end of utils =============*/


/*
  ����������� charset �� Hostname
*/

static charset_table_t *
charset_from_hostname(request_rec *r,charset_dir_t *dirconf)
{
  if(dirconf->strict_names == FL_ON)
    return strncmp_getcharset(dirconf,r->server->server_hostname,1,".");
  else 
    return strncmp_getcharset(dirconf,r->server->server_hostname,0,"");
}

/*
  ����������� charset �� URIHostname
*/

static charset_table_t *
charset_from_urihostname(request_rec *r,charset_dir_t *dirconf)
{
  const char *host;
  if(r->main) {
    if(r->main->hostname) host = r->main->hostname;
    else return NULL;
  }else{
    if(r->hostname) host = r->hostname;
    else return NULL;
  }
  if(dirconf->strict_names == FL_ON)
    return strncmp_getcharset(dirconf,host,1,".");
  else 
    return strncmp_getcharset(dirconf,host,0,"");
}

/*
  ����������� charset �� ���������� FORCE_CHARSET
*/

static charset_table_t *
charset_from_envvar(request_rec *r,charset_dir_t *dirconf)
{
  const char* var = ap_table_get(r->subprocess_env,"FORCE_CHARSET");
  if(var) 
    return exact_getcharset(dirconf,var);
  var = ap_table_get(r->subprocess_env,"REDIRECT_FORCE_CHARSET");
  if(var) 
    return exact_getcharset(dirconf,var);
  return NULL;
}

/* ����������� charset �� Portnumber */
static charset_table_t*
charset_from_portnumber (request_rec *r, charset_dir_t * dirconf)
{
  int port,i;
  portlist_t *pl = (portlist_t*)dirconf->portlist->elts;
  if(!r || !r->connection)
    return NULL;
  port = htons(r->connection->local_addr.sin_port);
  for(i=0;i<dirconf->portlist->nelts;i++)
    if(pl[i].port == port)
      return get_chtable(dirconf,pl[i].charset);
  return NULL;
}

/*
  ����������� charset �� Dirprefix
*/

static charset_table_t *
charset_from_dirprefix(request_rec *r, charset_dir_t *dirconf)
{
  charset_table_t *ret = NULL;
  int strict = 0; char *delim="/";
  if(dirconf->strict_names == FL_ON)
    strict = 1;
  ret = strncmp_getcharset(dirconf,r->uri+1,strict,delim);
  if(!ret && strlen(r->uri)>2 && !strncmp(r->uri,"/~",2))
    {
      char *p = strchr(r->uri+1,'/');
      if(p && strlen(p+1))
	ret = strncmp_getcharset(dirconf,p+1,strict,delim);
    }
  return ret;
}


/*
  ������� ���������� charset �� User-Agent:
*/
static charset_table_t*
charset_from_useragent(request_rec *r, charset_dir_t *dirconf)
{
  const char *agent=ap_table_get(r->headers_in,"User-Agent");
  array_header *ac = (array_header*)dirconf->agent_charset;
  table_entry *elts = (table_entry*)ac->elts;
  int maxlen = -1, len,i,match = -1,clen;


  len = agent?strlen(agent):0;
  if (!agent || !len) return NULL;

  for(i=0;i<ac->nelts;i++)
    {
      clen = strlen(elts[i].key);
      if(len>=clen && clen > maxlen && strstr(agent,elts[i].key))
	{
	  match = i;
	  maxlen = clen;
	}
    }
  if(match >=0)
    return get_chtable(dirconf,elts[match].val);
  else
    return NULL;
}


/*
  ���������� charset, ������� ����� ����� ������������� User query 
  (Accept, Accept-Charset)
*/

typedef struct
{
  char *cname;
  float prio;
}user_prio_t;

static int 
sort_by_prio(const void *a, const void *b)
{
  user_prio_t *c=(user_prio_t*)a,*d=(user_prio_t*)b;
  /* inverted values - we want descending-order sort */
  return c->prio>d->prio?-1:c->prio<d->prio?1:0;
}


static charset_table_t *
find_best_charset(request_rec *r,charset_dir_t *dirconf,
		  char *clientstr,int* has_wildcard)
{
  char *p,*q,*t;
  float weight;
  ap_pool *spool = ap_make_sub_pool(r->pool);
  array_header *u_charset = ap_make_array(spool,5,sizeof(user_prio_t));
  user_prio_t *u_prio;
  int i,max_prio,c_prio,match_idx=0;
  charset_table_t *ret=NULL,*tmp;
  *has_wildcard = 0;
  while (strlen(p=ap_getword(r->pool,(const char**)&clientstr,',')))
    {
      while (isspace(*p)) ++p;
      weight=1;
      for (q=p+strlen(p)-1; isspace(*q) && q > p ; q--) ;
      *(++q)='\0';
      if ((q=strchr(p,';')))
	{
	  *(q++)='\0';
	  for (t=q-2; isspace(*t) && t > p; t--) ;
	  *(++t)='\0';
	  if ((t=strchr(q,'=')))
	    {
	      sscanf(t+1,"%g",&weight);
	      weight = weight >1 ? 1: weight <0 ? 0 : weight;
	    }
	}
      if(!strcmp(p,"*"))
	*has_wildcard = 1;
      u_prio = ap_push_array(u_charset);
      u_prio->cname = ap_pstrdup(spool,p);
      u_prio->prio = weight;
    }
  /* sort u_charset array in descending order */
  qsort(u_charset->elts,u_charset->nelts,sizeof(user_prio_t),sort_by_prio);
  u_prio = (user_prio_t*)u_charset->elts;
  /* for each charset in user-passed values try to find 
     best-matches server charset */
  for(i=0;i<u_charset->nelts;i++)
    if(NULL!=(ret = exact_getcharset(dirconf,u_prio[i].cname)))
      {
	match_idx = i;
	break;
      }
	
  /* now we have 1st matching charset in ret and i=match_idx - 
     index in user query*/
  if(!ret) return NULL; /* no acceptable charsets in user query */

  /* find charset priority in CharsetPriority settings */
  t = (char*)ap_table_get(dirconf->charset_priority,ret->tablename);
  max_prio=t?t[0]:255; /* 255 - if unlisted */

  /* while other user's charsets exists 
     and user's priority not least than 1st found */
  for(; u_prio[i].prio >= u_prio[match_idx].prio 
	&& i<u_charset->nelts ; i++)
    if(NULL!=(tmp =exact_getcharset(dirconf,u_prio[i].cname)))
      {
	const char *chr_prio = 
	  ap_table_get(dirconf->charset_priority,ret->tablename);
	if(max_prio>(c_prio = (chr_prio?chr_prio[0]:255)))
	  {
	    max_prio = c_prio;
	    match_idx = i;
	    ret = tmp;
	  }
      }
  return ret;
}

static int 
have_different_charsets(charset_dir_t *dirconf)
{
  return dirconf->charset_tables->nelts > 1;
}


static int 
charset_alias_matches (char *uri, char *alias_fakename)
{
    char *end_fakename = alias_fakename + strlen (alias_fakename);
    char *aliasp = alias_fakename, *urip = uri;

    while (aliasp < end_fakename) {
	if (*aliasp == '/') {
	    /* any number of '/' in the alias matches any number in
	     * the supplied URI, but there must be at least one...
	     */
	    if (*urip != '/') return 0;
	    
	    while (*aliasp == '/') ++ aliasp;
	    while (*urip == '/') ++ urip;
	}
	else {
	    /* Other characters are compared literally */
	    if (*urip++ != *aliasp++) return 0;
	}
    }

    /* Check last alias path component matched all the way */

    if (aliasp[-1] != '/' && *urip != '\0' && *urip != '/')
	return 0;

    /* Return number of characters from URI which matched (may be
     * greater than length of alias, since we may have matched
     * doubled slashes)
     */

    return urip - uri;
}


static char *
try_charset_alias_list (request_rec *r, array_header *aliases, 
			int doesc, int *status)
{
    charset_alias_entry_t *entries = (charset_alias_entry_t *)aliases->elts;
    int i;
    
    for (i = 0; i < aliases->nelts; ++i) {
        charset_alias_entry_t *p = &entries[i];
        int l = charset_alias_matches (r->uri, p->fake);

        if (l > 0) {
	    *status = p->redir_status;
	    if (doesc) {
		char *escurl;
		escurl = ap_os_escape_path(r->pool, r->uri + l, 1);
		return ap_pstrcat(r->pool, p->real, escurl, NULL);
	    } else
		return ap_pstrcat(r->pool, p->real, r->uri + l, NULL);
        }
    }

    return NULL;
}

static int
check_mime_type(request_rec *r, array_header *a)
{
  processed_type_t *tp = (processed_type_t*)a->elts;
  const char *mimetype = r->content_type?r->content_type:ap_default_type(r);
  int i;

  for (i = 0; i < a->nelts; i++) {
    if (tp[i].typename[tp[i].len-1] == '/')
      {
	if(tp[i].typename[0]=='!' 
	   && !strncasecmp(mimetype,tp[i].typename+1,tp[i].len-1))
	  return 0;
	if (!strncasecmp(mimetype,tp[i].typename,tp[i].len))
	  return 1;
    }
    else {
      if(tp[i].typename[0]=='!' 
	 && !strcasecmp(mimetype,tp[i].typename+1))
	return 0;
      if (!strcasecmp(mimetype,tp[i].typename))
	return 1;
    }
  }
  return 0;
}  
  
API_EXPORT(int)
ra_check_type (request_rec *r)
{
  charset_dir_t   *dirconf = 
    ap_get_module_config(r->per_dir_config, &charset_module);
  /* quick fix */
  if (r->content_encoding || ap_table_get(r->headers_out,"Content-Encoding"))
      return 0;
  return check_mime_type(r,dirconf->processed_types);
}

static int
ra_check_normalize (request_rec *r)
{
  charset_dir_t   *dirconf = 
    ap_get_module_config(r->per_dir_config, &charset_module);
  return check_mime_type(r,dirconf->normalize_types);
}

static charset_redirect_t *
get_redirect(array_header *h, const char *charset)
{
  charset_redirect_t *c=(charset_redirect_t*)h->elts;
  int i;
  for(i=0;i<h->nelts;i++)
	if(!strcasecmp(c[i].charset,charset))
	  return c+i;
  return NULL;
}

/*
  main function for selecting charset
*/


static int 
find_code_page(request_rec *r)
{
  charset_table_t *charset=NULL, *cset_by_accept = NULL;
  charset_dir_t   *dirconf = ap_get_module_config(r->per_dir_config, &charset_module);
  const char *cset = NULL;
  char *cset2;
  int has_wildcard = 0,i,*l, zz_sc_flags = 0;
  int cs_method = mUnknown;
  table *e = r->subprocess_env;

#ifdef RUSSIAN_APACHE_DEBUG

  ap_log_error
    (APLOG_MARK,APLOG_DEBUG,r->server,
     "Entering mod-charset handler, URI: %s FILENAME: %s ARGS: %s PATH_INFO: %s MIMETYPE: %s FLAGS: %d SUBREQ: %s, REDIR: %s",
     r->uri,r->filename,r->args,r->path_info,r->content_type?r->content_type:ap_default_type(r),
     r->ra_codep ? r->ra_codep->cp_flags:0,
     r->main?"YES":"NO",r->prev?"YES":"NO");
#endif
  
  /* catch proxy requests */
  if (r->proxyreq) return DECLINED;
  /* mod_rewrite indicators */
  if (!strncmp(r->filename, "redirect:", 9)) return DECLINED; 
  if (!strncmp(r->filename, "gone:", 5)) return DECLINED; 
  if (!strncmp(r->filename, "passthrough:", 12)) return DECLINED; 
  if (!strncmp(r->filename, "forbidden:", 10)) return DECLINED; 

  /* 1st - try to redirect */
  {
    char *rel_uri,*redir;
    int status;
    
    /* It may have changed since last time, so try again */
    
    if ((rel_uri = try_charset_alias_list (r, dirconf->redirects, 
					   1, &status)) != NULL) 
      {
	if (ap_is_HTTP_REDIRECT(status)){
	  redir = 
	    ap_pstrcat (r->pool, ap_http_method(r),"://",
			ap_construct_server(r->pool, 
					    r->server->server_hostname, 
					    ntohs(r->connection->
						  local_addr.sin_port),
					    r),
			rel_uri, NULL);
	  ap_table_set (r->headers_out, "Location", redir);
	  return status;
	}
      }
  } /* end of redirect code */

#ifdef RUSSIAN_APACHE_DEBUG

  ap_log_error
    (APLOG_MARK,APLOG_DEBUG,r->server, "mod_charset handler continues");
#endif
  
  /* in any case set CHARSET_HTTP_SERVER variable */
  {
    char port[8];
    sprintf(port,"%d",htons(r->connection->local_addr.sin_port));
    ap_table_set(e,"CHARSET_SERVER_NAME",
		 ap_pstrcat(r->pool,r->server->server_hostname,":",port,NULL));
    ap_table_set(e,"CHARSET_SERVER_PORT",port);
    ap_table_set(e,"CHARSET_HTTP_METHOD",
		 ap_pstrcat(r->pool,ap_http_method(r),"://",NULL));
  }

  /* protect from unconfigured server */
  if(dirconf->charset_tables->nelts < 1 /* unconfigured server */
     || dirconf->turnoff == FL_ON) /* CharsetDisable On */
    {
      r->ra_codep=NULL; /* ensure */
      return DECLINED;
    }


#ifdef RUSSIAN_APACHE_DEBUG

  ap_log_error
    (APLOG_MARK,APLOG_DEBUG,r->server, "mod_charset handler after redirect tests");
#endif
  
  if(dirconf->disable_accept != FL_ON )
    {
      cset=ap_table_get(r->headers_in,"Accept-Charset");
      
      if (cset) 
	{
	  const char *agent = ap_table_get(r->headers_in,"User-Agent");
	  if(!bad_agent_accept(dirconf,agent,cset))
	    {
	      cset2 = ap_pstrdup(r->pool,cset);
	      ap_str_tolower(cset2);
	      if (!(cset_by_accept=find_best_charset(r,dirconf,
						     cset2,&has_wildcard)))
		{ 
		  /* cannot set charset specified in Accept: or Accept-Charset: */
		  if(!has_wildcard) 
		    {
		      ap_log_reason("Can't set requested charset",cset,r);
		      if (dirconf->reject_error == FL_ON)
			return DECLINED;
		    }
		}
	    } 
	  else 
	    {
	      cset_by_accept = NULL;
	    }
	}
    }
  else /* disable_accept == FL_ON */
    cset_by_accept = NULL;

  if(dirconf->selection_rules[0]==0)
    l = default_rule_list;
  else
    l = dirconf->selection_rules;

  for(i=0;i<MOD_CHARSET_SELECTION_RULES;i++)
    {
      if(l[i]==sNotused) break;
      else if(l[i] == sPortnumber)
	{
	  charset = charset_from_portnumber(r,dirconf);
	  cs_method = mPortnumber;
	}
      else if(l[i] == sHostname)
	{
	  charset = charset_from_hostname(r,dirconf);
	  cs_method = mHostname;
	}
      else if(l[i] == sURIHostname)
	{
	  charset = charset_from_urihostname(r,dirconf);
	  cs_method = mURIHostname;
	}
      else if(l[i] == sEnvVariable)
	{
	  charset = charset_from_envvar(r,dirconf);
	  cs_method = mEnvVariable;
	}
      else if(l[i] == sDirprefix)
	{
	  charset = charset_from_dirprefix(r,dirconf);
	  cs_method = mDirprefix;
	}
      else if(l[i] == sUseragent)
	{
	  if(cset_by_accept!=NULL) /* some charset found from Accept-Charset:
				      - not check user-agent */
	    break;
	  else if (!ap_is_empty_table(dirconf->agent_charset))
	    {
	      charset = charset_from_useragent(r,dirconf);
	      zz_sc_flags |= SCH_BY_UA; /* User-agent probed, so next 
					   request  may be accepted via 
					   User-Agent test */
	      cs_method = mUseragent;
	    }
	}
      
      if(charset!=NULL)	{
	if(l[i]    == sHostname 
	   || l[i] == sDirprefix 
	   || l[i] == sPortnumber 
	   || l[i] == sURIHostname
	   || l[i] == sEnvVariable
	   )
	  zz_sc_flags |= SCH_CAN_CACHE;
	break;
      }
    }

  if(cset_by_accept != NULL)
    {
      if(charset && !strcasecmp(cset_by_accept->tablename,charset->tablename))
	zz_sc_flags |= SCH_CAN_CACHE;
      else
	{
	  /* cannot cache */
	  zz_sc_flags &= (~(SCH_CAN_CACHE));
	  zz_sc_flags |= SCH_BY_ACCEPT;
	}
      charset=cset_by_accept;
      cs_method = mAcceptCharset;
    }
  
  /* try native charset */
  if(!charset && dirconf->charset_default)
    {
      charset = get_chtable(dirconf,dirconf->charset_default);
      cs_method = mDefault;
    }

  /* try 1st element in charset priority list */
  { /* just an inner scope */
    array_header *cp = (array_header*)dirconf->charset_priority;
    if(!charset && cp && cp->nelts > 0)
    {
      table_entry *e = (table_entry*)cp->elts;
      charset = get_chtable(dirconf,e->key);
      cs_method = mFirstInList;
    }
  }

  if(!charset)
    {
      array_header *cp = (array_header*)dirconf->charset_tables;
      /* 1st charset in charset list */
      if(cp)
	{
	  charset = (charset_table_t *) cp->elts;
	  cs_method = mFirstInList;
	}
    }

  if(dirconf->no_redirect_defaults == FL_ON)
    {
      if(cs_method == mUnknown 
	 || cs_method == mDefault 
	 || cs_method == mFirstInList)
	ap_table_set(r->subprocess_env,"CHARSET_NOREDIRECT","T");
    }

  /* ============ AutoRedirects =========================*/
  

  /* Redirect images to canonical URL (extra overhead - in theory, we
   shouldn't determine charset for Image normalization, but it possible, that
  CHARSET_NOREDIRECT is set on charset-determination stage */
  if(r->method_number == M_GET
     && !ap_table_get(r->subprocess_env,"CHARSET_NOREDIRECT") 
     && ap_is_initial_req(r) 
     &&  ra_check_normalize(r)  /* valid mime type for normalize */
     )
    {
      if (
	  dirconf->picture_url /* we should normalize picture URLs */
	  && (!dirconf->redir_pic_minsize /* no check for minimal size */
	       /* file exists and size > redir_pic_minsize */
	       ||(r->finfo.st_mode && r->finfo.st_size >= dirconf->redir_pic_minsize)
	       )
	  )
	{
	  if(!image_is_rewrited(r,dirconf,dirconf->picture_url))
	    {
	      const char *rd = rewrite_url(r,dirconf,dirconf->picture_url);
	      if(rd)
		{
		  ap_table_set(r->headers_out,"Location",rd);
		  return HTTP_MOVED_PERMANENTLY;
		}
	    }
/* 	  else */
/* 	    { */
 	      /* we SHOULD NOT process this file later because of dead_loop */ 
/* 	      return DECLINED; */
/* 	    } */
	}
    }

  if(r->method_number == M_GET      
     && charset 
     && !ap_table_get(r->subprocess_env,"CHARSET_NOREDIRECT") 
     && ap_is_initial_req(r) 
     && !ra_check_normalize(r)
     )
    {
      charset_redirect_t * redir = get_redirect(dirconf->auto_redirects,charset->tablename);
      if(redir && !already_rewrited(r,dirconf,redir))
	{
	  const char *new_url = rewrite_url(r,dirconf,redir);
	  if(new_url)
	    {
	      ap_table_set(r->headers_out,"Location",new_url);
	      return HTTP_MOVED_TEMPORARILY;
	    }
	}
    } /* end of redirection attempt */

  if(charset)
    {
#ifdef RUSSIAN_APACHE_DEBUG
  ap_log_error
    (APLOG_MARK,APLOG_DEBUG,r->server, "mod_charset: found client charset %s",charset->tablename);
#endif
      set_charset(charset,r,dirconf,zz_sc_flags); 
      if(r->ra_codep)
	{
	  if(r->ra_codep->cp_name)
	    ap_table_set (e, "CHARSET", r->ra_codep->cp_name);
	  if(r->ra_codep->cp_fromname) 
	    ap_table_set (e, "SOURCE_CHARSET",r->ra_codep->cp_fromname);
	  ap_table_set(e,"CHARSET_DETERMINED_BY",det_method_names[cs_method]);
	}
    }
  return DECLINED;
}

/************************************************************
 *
 * Copy preselected charset parameters to request structure
 *
 * this parameters w'be used in http_protocol.c module
 * to translate stream before transfering and for
 * picking up charset=...
 *
 * it also convert input headers, comming from client
 *
 */
static const char*
get_source_charset(request_rec *r, charset_dir_t *dirconf)
{
  const char *src_cs = NULL;
  char *ext,*fn;
  /* stolen from mod_mime */
  const char* var = ap_table_get(r->subprocess_env,"FORCE_SOURCE_CHARSET");
  if(var) return var;
  var = ap_table_get(r->subprocess_env,"REDIRECT_FORCE_SOURCE_CHARSET");
  if(var) return var;
  fn = strrchr(r->filename,'/');
  if(!fn) ext = r->filename;
  while((ext = ap_getword(r->pool, (const char**)&fn, '.')) && *ext)
    if(NULL!=(src_cs = ap_table_get(dirconf->charset_exts,ext)))
	break;
  
  if(!src_cs)
    src_cs = dirconf->charset_source;
  return src_cs;
}


static codepage_data_t*
make_codepage_data(ap_pool *p,void *table, void *revtable,
		   char *tablename,char *namefrom,char *lang)
{
  codepage_data_t *ra_codep;

  ra_codep=ap_palloc(p,sizeof(codepage_data_t));

  ra_codep->recode_buffer_in	=ap_pcalloc(p,sizeof(local_buf_t));
  ra_codep->recode_buffer_out	=ap_pcalloc(p,sizeof(local_buf_t));

  ra_codep->cp_flags	=0;
  ra_codep->cp_otabl_p  = table;
  ra_codep->cp_itabl_p	= revtable;
  ra_codep->cp_name	= tablename;
  ra_codep->cp_fromname	=namefrom;
  ra_codep->cp_lang	=lang;
#ifndef OLD_BREAD
  ra_codep->post_len = ra_codep->post_err =
      ra_codep->post_eof=ra_codep->post_errcode = 0;
#else
  ra_codep->postlen = ra_codep->errflag =ra_codep->errcode = 0;
#endif
  return ra_codep;
}

static void
change_clientconttype (request_rec *r)
{
  char *ct = ap_pstrdup(r->pool,ap_table_get(r->headers_in,"Content-Type"));
  char *w,*ww,*p;
  char *ret;
  if(!r || !r->ra_codep || !r->ra_codep->cp_fromname) return;
  if(!ct) return;

  w=ct;
  while((w=strchr(w,';')))
    {
      p = w+1;
      while(*p==' ') p++;
      if(!strncasecmp(p,"charset=",8) || !strncasecmp(p,"charset ",8))
	break;
      w++;
    }
  if(!w) return;

  w=strchr(ct,';');
  *w++='\0'; /* ct holds an content-type w/o attributes */
  ret=ct;

  while(w)
    {
      if((ww = strchr(w,';')))
	*ww='\0';
      p=w;
      while(*p && *p==' ') p++;
      if(!strncasecmp(p,"charset=",8) || !strncasecmp(p,"charset ",8))
	ret=ap_pstrcat(r->pool,ret,"; charset=",r->ra_codep->cp_fromname,NULL);
      else
	ret=ap_pstrcat(r->pool,ret,";",w,NULL);

      if(ww)
	w=ww+1;
      else
	break;
    }
  ap_table_setn(r->headers_in,"Content-Type",ret);
}

static void 
set_charset(charset_table_t *charset,  request_rec *r, 
	    charset_dir_t *dirconf,int flags)
{
  int i;
  int no_recode_data = 0;
  const char *agent;
  const char *src_cs;
  array_header *client_headers=(array_header*) r->headers_in;
  table_entry *el = (table_entry *)client_headers->elts;
  recode_table_t *rtbl=NULL; 
  charset_table_t *new_cset;

#ifdef RUSSIAN_APACHE_DEBUG
  ap_log_error
    (APLOG_MARK,APLOG_DEBUG,r->server,
     "Before subrequests tests: prev=%s,main=%s,codep=%s",
     r->prev?"SET":"UNSET",
     r->main?"SET":"UNSET",
     r->ra_codep?"SET":"UNSET");
#endif

    if (r->prev != NULL && r->prev->ra_codep && (r->prev->ra_codep->cp_flags & RA_ALREADY_RECODED))
    {
      no_recode_data = 1;
    }


#ifdef RUSSIAN_APACHE_DEBUG
      ap_log_error   (APLOG_MARK,APLOG_DEBUG,r->server,"Continue after redirect test, will-recode=%d",!no_recode_data);
#endif
     
  src_cs = get_source_charset(r,dirconf);

  if(src_cs)
    rtbl = find_recode_table(charset->recode_tables,src_cs);
  else
    return; /* nothing known about source charset */


  if(!rtbl)
    {
      new_cset = exact_getcharset(dirconf,src_cs);
      if(new_cset)
	charset = new_cset;
      r->ra_codep = make_codepage_data(r->pool,dirconf->emptytbl,dirconf->emptytbl,
				       (char*)src_cs,(char*)src_cs,charset->lang);
      r->ra_codep->cp_otabl_p = NULL;
      r->ra_codep->cp_itabl_p = NULL;
    }
  else 
    {
      r->ra_codep = make_codepage_data(r->pool,rtbl->convtbl_ptr,rtbl->revtbl_ptr,
				       charset->tablename,rtbl->namefrom,charset->lang);
      if(rtbl->flags & RA_WIDE_CHARS_SC)
	r->ra_codep->cp_flags |= RA_WIDE_CHARS_SC;
    }


    if(!charset->flags & MOD_CHARSET_NO_CHARSETNAME) 
    r->ra_codep->cp_flags |= RA_NEED_CHARSET;

  if(dirconf->matchlang != FL_ON)
    r->ra_codep->cp_flags |= RA_IGNORE_LANGUAGE;

  if(dirconf->recode_headers == FL_ON)
    r->ra_codep->cp_flags |= RA_RECODE_HEADERS;

  if(dirconf->recode_filenames == FL_ON || dirconf->recode_filenames==FL_DEFAULT)
    r->ra_codep->cp_flags |= RA_RECODE_FILENAMES;

  if(dirconf->override_expires != FL_OFF)
    r->ra_codep->cp_flags |= RA_OVERRIDE_EXPIRES;

  if (have_different_charsets(dirconf))
    {
      if(dirconf->disable_accept != FL_ON)
	r->ra_codep->cp_flags |= RA_VARY_ACCEPT_CHARSET;
      if(flags & SCH_BY_UA)
	r->ra_codep->cp_flags |= RA_VARY_USERAGENT;

      if ((r->proto_num < 1001) 
	  && !(flags & SCH_CAN_CACHE) 
	  && ((flags & SCH_BY_UA) || (flags & SCH_BY_ACCEPT)))
	{
          r->ra_codep->cp_flags |= RA_NEED_EXPIRES; 
	  /* Expires will be set in send_http_header */
        }
    }

  if(dirconf->disable_expires == FL_ON)
    r->ra_codep->cp_flags &= RA_DONT_NEED_EXPIRES;

  /* check for ProcessMethodsIn */
  if(dirconf->process_in && !(dirconf->process_in & PROCESS_ALL)) 
    {
      if(dirconf->process_in & PROCESS_NONE 
	 || !(dirconf->process_in & (1<<r->method_number)))
	 r->ra_codep->cp_itabl_p = NULL;
    }

  /* check for ProcessMethodsOut */
  if(dirconf->process_out && !(dirconf->process_out & PROCESS_ALL)) 
    {
      if(dirconf->process_out & PROCESS_NONE 
	 || !(dirconf->process_out & (1<<r->method_number)))
	 r->ra_codep->cp_otabl_p = NULL;
    }

  /* check for ProcessMultipartForm */
  if(dirconf->multipart_forms == FL_OFF) {
    const char * intype = ap_table_get(r->headers_in,"Content-Type");
    if(intype && !strncasecmp(intype,"multipart/form-data",19))
      r->ra_codep->cp_itabl_p = NULL;
  }

  /* Lynx and some other can't accept Content-type: text/html; charset=name */
  /* try to find current agent in bad list */
  if ((agent = ap_table_get(r->headers_in,"User-Agent")))
    if(agent && strstr_table_get(dirconf->bad_agent,agent))
      r->ra_codep->cp_flags &= RA_DONT_NEED_CHARSET;

  if(r->main == NULL && r->ra_codep->cp_itabl_p!=NULL && !no_recode_data
     && strcmp(r->content_type?r->content_type:"DuMmYVal", DIR_MAGIC_TYPE))
    {
      /* set 'DATA recoded flag' for current request and all prev. requests in redirect chain */
      r->ra_codep->cp_flags |= RA_ALREADY_RECODED;
      {
	request_rec *rr=r->prev;
	while(rr)
	  {
	    if(rr->ra_codep)
	      rr->ra_codep->cp_flags |= RA_ALREADY_RECODED;
	    rr = rr->prev;
	  }
      }

#ifdef RUSSIAN_APACHE_DEBUG
      ap_log_error   (APLOG_MARK,APLOG_DEBUG,r->server,   "Recoding client data");
#endif
      /* Let's begin to convert input data from client */
      change_clientconttype(r);
      if (r->the_request && strlen(r->the_request))
	ra_in_place_convert_by_table_esc(r->the_request,strlen(r->the_request), 
					 r->ra_codep->cp_itabl_p);
      
      if (r->uri && strlen(r->uri) &&
	  strncmp(r->uri,"INTERNALLY GENERATED file-relative req",38))
	ra_in_place_convert_by_table_esc(r->uri,strlen(r->uri), r->ra_codep->cp_itabl_p);
      
      if (r->ra_codep->cp_flags & RA_RECODE_FILENAMES 
	  && r->filename && strlen(r->filename))
	ra_in_place_convert_by_table_esc(r->filename,strlen(r->filename), 
			     r->ra_codep->cp_itabl_p);
      
      if (r->path_info && strlen(r->path_info))
	{
	  if(!ap_table_get(r->subprocess_env,"CHARSET_SAVED_PATH_INFO"))
	    ap_table_setn(r->subprocess_env,"CHARSET_SAVED_PATH_INFO",
			  ap_pstrdup(r->pool,r->path_info));
	  ra_in_place_convert_by_table_esc(r->path_info,strlen(r->path_info),
					   r->ra_codep->cp_itabl_p);
	}
      
      if (r->args && strlen(r->args))
	{
	  if(!ap_table_get(r->subprocess_env,"CHARSET_SAVED_QUERY_STRING"))
	    ap_table_setn(r->subprocess_env,"CHARSET_SAVED_QUERY_STRING",
			  ap_pstrdup(r->pool,r->args));
	  ra_in_place_convert_by_table_esc(r->args,strlen(r->args), r->ra_codep->cp_itabl_p);
	}
	  
      
      /* Time to convert headers from client */
      for (i = 0; i < client_headers->nelts; i++)
	{
	  int l;
	  if (el[i].key && (l=strlen(el[i].key)))
	    ra_in_place_convert_by_table_esc(el[i].key,l,r->ra_codep->cp_itabl_p);
	  if (el[i].val && (l=strlen(el[i].val)))
	    ra_in_place_convert_by_table_esc(el[i].val,l, r->ra_codep->cp_itabl_p);
	}
    }
#ifdef RUSSIAN_APACHE_DEBUG

  ap_log_error
    (APLOG_MARK,APLOG_DEBUG,r->server,
     "exiting set_charset (after subrequest tests): URI: %s FILENAME: %s ARGS: %s PATH_INFO: %s MIMETYPE: %s FLAGS: %d SUBREQ: %s",
     r->uri,r->filename,r->args,r->path_info,r->content_type?r->content_type:ap_default_type(r),
     r->ra_codep ? r->ra_codep->cp_flags:0,

     r->main?"YES":"NO");
#endif
}

/* ======== STRIP META-HTTP handler ===========*/

/* 
   find and return 1st <tag>, 
   printout all other characters before tag (via ap_rputc) 
*/
static char* 
get_tag(request_rec *r, FILE *f, char **buf,int *maxbytes)
{
  int c;
  char *str = NULL;
  int bytes =0,mbytes = *maxbytes;

  while(1) /* find begin of tag */
    {
      c=getc(f);
      if(feof(f) || ferror(f) || (c == -1)) 
	return str;
      if(c=='<')
	{
	  str = *buf;
	  memset(str,0,mbytes);
	  str[bytes++]=c;
	  break;
	}
      else
	ap_rputc(c,r);
    }
  /*
    now we've read all before <tag> and '<' 
    read to 1st occurence of '>' or to EOF
  */
  while(1)
    {
      c=getc(f);
      if(feof(f) || ferror(f) || (c == -1)) 
	return str;
      if(bytes==mbytes)
	{
	  *buf = ap_pcalloc(r->pool,mbytes*2);
	  mbytes*=2;
	  *maxbytes = mbytes;
	  memcpy(*buf,str,bytes);
	  str = *buf;
	}
      str[bytes++]=c;
      if(c=='>')
	return str;
    }
}

enum tags
{
  tMETAHTTP,
  tOTHER
};
  
static int 
check_value (const char * s ){
  if(strncasecmp(s,"http-equiv",10))
    return tOTHER;
  s+=10;
  while(isspace(*s) || *s=='\"' || *s=='=')
    s++;
  if(strncasecmp(s,"Content-Type",12))
    return tOTHER;
  s+=12;
  if(isspace(*s) || *s == '\"')
    return tMETAHTTP;
  return tOTHER;
}

static int 
parse_tag(char *stag)
{
  char *s = stag;
  if(*s++!='<') return tOTHER;
  while(isspace(*s)) s++;
  if(!strncasecmp(s,"meta",4))
    {
      s+=4;
      if(!isspace(*s)) return tOTHER;
    again:
      if(tMETAHTTP==check_value(s))
	return tMETAHTTP;
      while(!isspace(*s)){
	if(*s == '>')
	  return tOTHER; 
	s++;
      }
      while(isspace(*s))s++;
      goto again;
    }
  return tOTHER;
}


#define BF_SIZE 1024

static void 
send_stripped_file(request_rec *r,FILE* f)
{
  int tag;
  char *stag;
  char *buf;
  int mbytes;

  buf = ap_palloc(r->pool,mbytes=BF_SIZE);
  while(1)
    {
      stag=get_tag(r,f,&buf,&mbytes);
      if(stag==NULL)
	return;
      tag = parse_tag(stag);
      if(tag==tMETAHTTP)
	{
	  char *stub="Meta http equivalent was here";
	  int i=0;
	  unsigned sztag=strlen(stag)-9, szstub=strlen(stub);
	  if(ra_charset_active(r) && ra_flag(r,RA_WIDE_CHARS_SC))
	    sztag = ra_calc_wide_len(stag,sztag+9,
				  (wide_table_t*)r->ra_codep->cp_otabl_p)-9;
	  ap_rputs("<!-- ",r);
	  for(i=0; i<sztag; i++)
	    ap_rputc(i>=szstub ? ' ' : stub[i],r);
	  ap_rputs(" -->",r);
	}
      else
	ap_rputs(stag,r);
    }
  return; /* not reached */
}

static int 
strip_http_handler(request_rec *r)
{
  int errstatus;
  FILE *f;
  

  if (!strncmp(r->filename, "proxy:", 6)) return DECLINED;
  if (r->method_number != M_GET) return DECLINED;
  if (r->finfo.st_mode == 0) 
    {
      ap_log_reason("File does not exist", r->filename, r);
      return NOT_FOUND;
    }
  if(r->ra_codep && r->ra_codep->cp_otabl_p && ra_flag(r,RA_WIDE_CHARS_SC))
    {
      unsigned char buf[IOBUFSIZE];
      int len = 0,n;
      FILE *f = ap_pfopen(r->pool,r->filename,"r");
      while(f && !feof(f)) 
	{
	  while ((n= fread(buf, sizeof(char), IOBUFSIZE, f)) < 1
		 && ferror(f) && errno == EINTR)
	    continue;
	  if (n > 0) 
	    len +=ra_calc_wide_len(buf,n,
				(wide_table_t*)r->ra_codep->cp_otabl_p);
	  else 
	    break;
	}
      if ((errstatus = ap_set_content_length (r, len)))
	return errstatus;
	
      r->ra_codep->cp_flags |=RA_CONTLEN_PROCESSED;
    }
  else 
    {
      if ((errstatus = ap_set_content_length (r, r->finfo.st_size)))
	return errstatus;
    }
    
  f = ap_pfopen (r->pool,r->filename, "r");
  
  if (f == NULL) 
    {
      ap_log_reason("file permissions deny server access", r->filename, r);
      return FORBIDDEN;
    }

  ap_update_mtime (r, r->finfo.st_mtime);
  ap_set_last_modified (r);
  ap_set_etag(r); 
  if ((errstatus = ap_meets_conditions(r)) != OK) 
    return errstatus;
 
  ap_soft_timeout ("send", r);
  
  ap_send_http_header (r);
  if(!r->header_only)
    send_stripped_file(r,f);
  ap_pfclose(r->pool,f);
  return OK;
}

#ifdef RUSSIAN_APACHE_TEST

static int 
ra_test_handler(request_rec *r)
{
  int errstatus;
  int i;
  char buf[128],bigbuf[12800];
  int r_len=1,g_len,biglen=0;
  char *c;
  
  bzero(bigbuf,sizeof(bigbuf));
  if (!strncmp(r->filename, "proxy:", 6)) return DECLINED;
  if (r->method_number != M_GET && r->method_number!=M_POST) return DECLINED;
  r->content_type="text/plain";
  r->mtime=time(NULL);
  ap_set_last_modified(r);
  ap_table_addn(r->headers_out,"X-RA-Test",ap_escape_uri(r->pool,"������� ����"));
  ap_soft_timeout ("send", r);
  ap_setup_client_block(r, REQUEST_CHUNKED_ERROR);
  if (ap_should_client_block(r)) 
      {
	  ap_rputs("POST data:\n",r);
	  while((g_len = ap_get_client_block(r,buf,r_len))>0 && biglen 
	      < 12700)
	      {
		  buf[g_len] = '\0';
		  strcat(bigbuf,buf);
		  strcat(bigbuf," | ");
		  biglen+=g_len+3;
		  if(r_len<126) r_len++;
	      }
      }
  ap_send_http_header (r);
  ap_rprintf(r,"Post data: %s\n",bigbuf);
  ap_rputs("RA-Test handler\n",r);
  ap_rputs("rputc: ",r);
  for(i=0;i<30;i++) ap_rputc('�'+i,r);
  ap_rputc('\n',r);
  ap_rputs("rputs: �������� ap_rputs\n",r);
  c="rwrite: �������� ap_rwrite\n";
  ap_rwrite(c,strlen(c),r);
  
  ap_rprintf(r,"%s: string: %s, string2: %s, char: %c, digit: %d\n","rprintf","��������","����������������������������������",'�',10);
  
  c=ap_pcalloc(r->pool,8192);
  memset(c,'�',8191);
  ap_rprintf(r,"Trying to print LONG string: %s\n",c);
  
  ap_rvputs(r,"rvputs: ","��������","\n",NULL);
  ap_rputs("done\n",r);
  ap_rflush(r);
  return OK;
}
#endif




handler_rec charset_handlers[] = {
{ "strip-meta-http",strip_http_handler },
#ifdef RUSSIAN_APACHE_TEST
{ "ra-test",ra_test_handler },
#endif
{ NULL }
};


int translate_charset_redir(request_rec *r)
{
    void *sconf = r->server->module_config;
    charset_server_conf_t *serverconf =
        (charset_server_conf_t *)ap_get_module_config(sconf, &charset_module);
    char *rel_uri,*redir;
    int status;

#ifdef __EMX__
    /* Add support for OS/2 drive names */
    if ((r->uri[0] != '/' && r->uri[0] != '\0') && r->uri[1] != ':')
#else    
    if (r->uri[0] != '/' && r->uri[0] != '\0') 
#endif    
        return DECLINED;

    if ((rel_uri = try_charset_alias_list (r, serverconf->charset_redirects, 
				       1, &status)) != NULL) {


	if (ap_is_HTTP_REDIRECT(status)) {
	    /* include QUERY_STRING if any */
	    if (r->args) {
		rel_uri = ap_pstrcat (r->pool, rel_uri, "?", r->args, NULL);
	    }

	    redir = ap_pstrcat (r->pool, ap_http_method(r),"://",
			     ap_construct_server(r->pool, 
					      r->server->server_hostname, 
					      ntohs(r->connection->
						    local_addr.sin_port),r),
			     rel_uri, NULL);

	    ap_table_set (r->headers_out, "Location", redir);
	}
        return status;
    }
    return DECLINED;
}

void charset_startup (server_rec *s, ap_pool *p) {
#if MODULE_MAGIC_NUMBER >= 19980507
    ap_add_version_component(MOD_CHARSET_VERSION);
#endif
}



/************************************************************/
module charset_module = {
  STANDARD_MODULE_STUFF,
  charset_startup,				/* initializer */
  create_charset_dir_conf,	/* dir config creater */
  merge_charset_dir_conf,
  create_charset_config,	/* server config */
  merge_charset_config,
  charset_cmds,			/* command table */
  charset_handlers,		/* handlers */
  translate_charset_redir,	/* filename translation */
  NULL,				/* check_user_id */
  NULL,				/* check auth */
  NULL,				/* check access */
  NULL,				/* type_checker */
  find_code_page,		/* fixups */
  NULL,				/* logger */
  NULL,				/* header parser */
  NULL,				/* child_init */
  NULL,				/* child_exit */
  NULL				/* post_read_request */
};

