#define RARVER_MAJOR     3
#define RARVER_MINOR    80
#define RARVER_BETA      0
#define RARVER_DAY      16
#define RARVER_MONTH     9
#define RARVER_YEAR   2008
