package P::WebFetcher;

use strict;
use LWP::UserAgent;

my $TIMEOUT = 3000;

sub new
{
	my $class = shift;
	my (%opts) = @_;

	my $timeout = $opts{timeout} || $TIMEOUT;
	my $self = {
		useragent => new LWP::UserAgent,
		last => undef,
	};
	$self->{useragent}->timeout($timeout);
	bless($self, $class);
}

sub fetch
{
	my ($self, $url) = @_;

	my $request = new HTTP::Request GET => $url;
	my $res = $self->{useragent}->request($request);

	if ($res->is_success)
	{
		my $content_length = $res->headers->header('content-length');
		$self->{last} = $res;
#		return (length($res->content) == $content_length) ? $res->content : undef;
		return $res->content;
	}
	else
	{
		warn $res->status_line." \n";
		return undef;
	}
}

1;
