#!/usr/bin/perl

#use lib '@APACHE_PREFIX@/perl';

use Apache;

1;
