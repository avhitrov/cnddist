package HTML::Mason;
use HTML::Mason;
use HTML::Mason::ApacheHandler;
use strict;

my $parser = new HTML::Mason::Parser;
my $interp = new HTML::Mason::Interp(parser=>$parser,
   comp_root=>'@MASON_COMP@',
   data_dir=>'@APACHE_PREFIX@/mason/data');

my $ah = new HTML::Mason::ApacheHandler(interp=>$interp);

chown(Apache->server->uid, Apache->server->gid, $interp->files_written);

sub handler
{
    my($r) = @_;
    $ah->handle_request($r);
}

1;
