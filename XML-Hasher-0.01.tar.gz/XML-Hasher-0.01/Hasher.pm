package XML::Hasher;

use strict;
use vars qw($VERSION);
use Data::Dumper;
use XML::Parser;
use Convert::Cyrillic;

$VERSION = '0.01';

sub new
{
	my $class = shift;

	my $self = { parser => new XML::Parser(Style => 'Tree') };
	bless($self, $class);
}

sub parse
{
	my ($self, $xml_text) = @_;

	$xml_text =~ s/encoding="(.*?)"/encoding="UTF-8"/i;
	my $enc = $1;

	my $enc_rel = {
		'UTF-8' => 'UTF8',
		'windows-1251' => 'WIN',
		'koi8' => 'KOI8',
	};

	#$self->escape_specials(\$xml_text);

	#$xml_text = Convert::Cyrillic::cstocs($enc_rel->{$enc}, 'UTF8', $xml_text);

	my $tree = $self->{parser}->parse($xml_text);

	#$tree = eval(Convert::Cyrillic::cstocs('UTF8', 'KOI8', 'my '.Dumper($tree)));

	my $output = {};
	xml_hash($tree, \$output);

	return $output;
}

sub xml_hash
{
	my ($tree, $hash_ref) = @_;
	my $hash = $$hash_ref;

	my $attributes = shift @$tree if ref($tree->[0]) eq 'HASH';

	if ($attributes && scalar %$attributes)
	{
		$hash->{__attr__} = $attributes;
	}

	my $ntags = 0;
	my $h_content;

	while (my ($tag, $content) = splice(@$tree, 0, 2))
	{
		if ($tag eq '0')
		{
			$h_content = $content;
		}
		else
		{
			$ntags++;
			if (exists($hash->{$tag}))
			{
				if (ref($hash->{$tag}) eq 'ARRAY')
				{
					push @{ $hash->{$tag} }, {};
				}
				else
				{
					$hash->{$tag} = [ $hash->{$tag}, {} ];
				}
				xml_hash($content, \$hash->{$tag}->[-1]);
			}
			else
			{
				$hash->{$tag} = {};
				xml_hash($content, \$hash->{$tag});
			}
		}
	}
	if (defined($h_content))
	{
		if ($ntags == 0)
		{
			$$hash_ref = $h_content;
		}
		else
		{
			$hash->{__content__} = $h_content;
		}
	}
}

sub escape_specials
{
	my ($self, $text_ref) = @_;

	my $period = chr(133);
	$$text_ref =~ s/$period/.../g;

	$$text_ref =~ s/\202/,/g;
	$$text_ref =~ s/\204/"/g;
	$$text_ref =~ s/\213/</g;
	$$text_ref =~ s/\221/'/g;
	$$text_ref =~ s/\222/'/g;
	$$text_ref =~ s/\223/"/g;
	$$text_ref =~ s/\224/"/g;
	$$text_ref =~ s/\225/-/g;
	$$text_ref =~ s/\226/-/g;
	$$text_ref =~ s/\227/-/g;
	$$text_ref =~ s/\233/>/g;
	$$text_ref =~ s/\246/|/g;
	$$text_ref =~ s/\253/"/g;
	$$text_ref =~ s/\271/N/g;
	$$text_ref =~ s/\273/"/g;
}

1;
