package DateTime::Locale::ru;

use strict;
use base 'DateTime::Locale::ru_RU';

1;
