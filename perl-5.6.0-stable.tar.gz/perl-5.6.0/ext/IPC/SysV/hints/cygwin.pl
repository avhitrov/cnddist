# SysV IPC is an optional Cygwin package
$self->{LIBS} = ['-lcygipc']
