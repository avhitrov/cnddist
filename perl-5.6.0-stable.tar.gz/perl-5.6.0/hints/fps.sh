ccflags="$ccflags -J"
