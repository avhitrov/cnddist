DNA sequence useful for testing animate(1) program from

  ftp://ftp.x.org/contrib/applications/ImageMagick/

Animate(1) is a program that can display image sequences on any X server.
Type

  make -i
  animate dna.miff

ImageMagick requires POV to generate the DNA image sequence.
Alternately, you can get the image sequence as

  ftp://ftp.x.org/contrib/applications/ImageMagick/ImageMagick.animation.tar.Z
