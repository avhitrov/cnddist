This is just a template for the future ImageMagick user guide.  It has
been released to allow users to contribute sections or chapters.
Don't expect a final version of the guide before July 2014.
