/*
 *  compat.h -- backward compatibility header for ap_compat.h
 */

#ifdef __GNUC__
#warning "This header is obsolete, use ap_compat.h instead"
#endif

#include "ap_compat.h"
