package Crypt::AuthEnc;

use strict;
use warnings;
our $VERSION = '0.044';

sub CLONE_SKIP { 1 } # prevent cloning

1;

__END__
 
=head1 NAME

Crypt::AuthEnc - [internal only]

=cut