##############################################################################
# $HeadURL$
# $Id$
#
# TODO: some docs
##############################################################################
package XML::TrivialSAX::Handler;

use strict;
use warnings 'all';
use vars qw($VERSION);

use Carp;
use Data::Dumper;
use Encode qw();
use XML::TrivialSAX::Element;


$VERSION = '0.01';

sub new {
	my ($package, %opts) = @_;
	my $self = {
		debug   => $opts{debug},
		element => $opts{element}     || croak("Not found required parameter 'element'"),
		encode  => ref $opts{encode}  ?  $opts{encode}  : \&XML::TrivialSAX::Handler::encode,
		process => ref $opts{process} ?  $opts{process} : \&XML::TrivialSAX::Handler::process,
		stack   => undef,
	};

	bless $self, $package;
}

sub start_document {
	my $self = shift;

	croak "start_document called with non-empty elements stack" if ref $self->{stack} && @{$self->{stack}};
	warn "start_document() called\n" if $self->{debug};
	$self->{stack} = [];
}

sub end_document {
	my $self = shift;

	croak "end_document called with non-empty elements stack" if ref $self->{stack} && @{$self->{stack}};
	warn "end_document() called\n" if $self->{debug};
}

sub start_element {
	my ($self, $el) = @_;

	warn "start_element() called for element '$el->{Name}'\n" if $self->{debug};
	my $e = XML::TrivialSAX::Element->new($el->{Name},
	        attrs => {( map { $_ => $self->{encode}->($el->{Attributes}->{$_}) }
	                    keys %{$el->{Attributes}} )} );
	$self->{stack}->[0]->add_child($e) if @{$self->{stack}};
	unshift @{$self->{stack}}, $e;
}

sub end_element {
	my ($self, $el) = @_;

	my $e = shift @{$self->{stack}};
	croak "current element '$e->{name}' while closing '$el->{Name}'" unless $e->{name} eq $el->{Name};
	warn "end_element() called for element '$el->{Name}'\n" if $self->{debug};
	$self->{process}->($e) if $el->{Name} eq $self->{element};
}

sub characters {
	my ($self, $el) = @_;

	croak "characters() called with empty elements stack" unless ref $self->{stack} && @{$self->{stack}};
	$self->{stack}->[0]->{content} = $self->{encode}->($el->{Data}) if $el->{Data};
}

sub encode {
	# Default implementation.
	# You may subclass XML::TrivialSAX::Handler and override it,
	# or pass callback-reference to constructor ('encode' options).
	Encode::encode('koi8-r', shift, Encode::FB_HTMLCREF);
}

sub process {
	# Default implementation.
	# You may subclass XML::TrivialSAX::Handler and override it,
	# or pass callback-reference to constructor ('process' options).
	warn "process() called, dump here: ".Dumper(shift)."\n";
}

1;
