##############################################################################
# $HeadURL$
# $Id$
#
# TODO: some docs
##############################################################################
package XML::TrivialSAX::Parser;

use strict;
use warnings 'all';
use vars qw($VERSION);

use Carp;
use XML::Parser::PerlSAX;
use XML::TrivialSAX::Handler;


$VERSION = '0.01';

sub new {
	my ($package, %opts) = @_;
	my $self = {
		debug    => $opts{debug},
		encode   => $opts{encode},
		encoding => $opts{encoding},
	};

	bless $self, $package;
}

sub parse {
	my ($self, $source, %opts) = @_;

	my $xml;
	if (ref $source eq 'SCALAR') {
		# reference to very long XML string
		$xml = ${$source};
	} elsif (ref $source eq 'GLOB') {
		# opened XML file handle
		$xml = $self->load($source);
	} elsif ($source && ! ref $source) {
		# path to XML file
		open XML, "<$source" or croak "Can't read $source";
		$xml = $self->load(\*XML);
		close XML;
	} else {
		# what's it??
		croak("Unknown type of XML source: ".ref($source));
	}

	my $s = { String => ${$xml} };
	$s->{Encoding} = $opts{encoding} || $self->{encoding} if $opts{encoding} || $self->{encoding};

	my %hopts;
	$hopts{debug}   = 1 if $opts{debug} || $self->{debug};
	$hopts{element} = $opts{element};
	$hopts{encode}  = $opts{encode} || $self->{encode};
	$hopts{process} = $opts{process};

	my $h = XML::TrivialSAX::Handler->new(%hopts);
	XML::Parser::PerlSAX->new->parse(Source => $s, DocumentHandler => $h);
}

sub load {
	my ($self, $fd) = @_;

	local $/;
	my $xml = <$fd>;
	\$xml;
}

1;
