##############################################################################
# $HeadURL$
# $Id$
#
# TODO: some docs
##############################################################################
package XML::TrivialSAX::Element;

use strict;
use warnings 'all';
use vars qw($VERSION);


$VERSION = '0.01';

sub new {
	my ($package, $name, %opts) = @_;
	my $self = {
		name     => $name,
		attrs    => ref $opts{attrs}    ? $opts{attrs}    : {},
		children => ref $opts{children} ? $opts{children} : {},
		content  => $opts{content},
   	};

	bless $self, $package;
}

sub name {
	shift->{name};
}

sub attrs {
	shift->{attrs};
}

sub attr {
	my ($self, $attr, $def) = @_;

	return $self->{attrs}->{$attr} if exists $self->{attrs}->{$attr};
   	$def || '';
}

sub content {
	my $self = shift;

	$self->{content} = shift if @_;
	$self->{content} || '';
}

sub children {
	my ($self, $name) = @_;

	return $self->{children} unless $name;
	return ref $self->{children}->{$name} ? $self->{children}->{$name} : [];
}

sub add_child {
	my ($self, $child) = @_;

	$self->{children}->{$child->name} = [] unless ref $self->{children}->{$child->name};
	push @{$self->{children}->{$child->name}}, $child;
}

1;
